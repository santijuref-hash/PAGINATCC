import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
export default function LoginCEO() {
 const navigate = useNavigate();
 const [usuario, setUsuario] = useState("");
 const [password, setPassword] = useState("");
 const [error, setError] = useState("");
 const handleLogin = (e) => {
 e.preventDefault();
 setError("");
 // Hardcodeado
 if (usuario === "CEOTCC" && password === "1234") {
 localStorage.setItem(
 "usuarioCEO",
 JSON.stringify({ username: "CEOTCC", role: "CEO", id: 1 })
 );
 navigate("/dashboard-ceo");
 } else {
 setError("Usuario o contraseña incorrectos");
 }
 };
 return (
 <div className="min-h-screen flex items-center justify-center bg-gradient-to-br fromblue-50 to-blue-100 p-6 relative">
 <button
 onClick={() => navigate("/roles")}
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all"
 >
 <ArrowLeft size={26} />
 </button>
 <div className="bg-white shadow-lg rounded-2xl p-8 w-full max-w-md">
 <h2 className="text-2xl font-bold text-center text-blue-900 mb-6">
 Login CEO
 </h2>
 <form onSubmit={handleLogin} className="space-y-4">
 <input
 type="text"
 placeholder="Usuario"
 value={usuario}
 onChange={(e) => setUsuario(e.target.value)}
 required
 className="w-full p-3 border rounded-lg focus:ring focus:ring-blue-200"
 />
 <input
 type="password"
 placeholder="Contraseña"
 value={password}
 onChange={(e) => setPassword(e.target.value)}
 required
 className="w-full p-3 border rounded-lg focus:ring focus:ring-blue-200"
 />
 {error && <p className="text-red-500 text-sm text-center">{error}</p>}
 <button
 type="submit"
 className="w-full py-2 bg-blue-500 text-white rounded-lg shadow hover:bg-blue600 transition"
 >
 Ingresar
 </button>
 </form>
 </div>
 </div>
 );
}
