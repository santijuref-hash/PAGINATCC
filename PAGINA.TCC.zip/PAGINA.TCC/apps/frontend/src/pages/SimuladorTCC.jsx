// SimuladorTCC.jsx (COMPLETO Y CORREGIDO)

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import api from "../services/api";

export default function SimuladorTCC() {
  const navigate = useNavigate();
  const [hospitalld, setHospitalld] = useState("");
  const [hospitales, setHospitales] = useState([]);
  const [tccActivos, setTccActivos] = useState([]);
  const [pacientes, setPacientes] = useState([]);
  const [ultimaHora, setUltimaHora] = useState({}); // última alerta por dispositivo
  
  const necesidades = [
    { tipo: "URGENCIA", color: "bg-red-500", urgencia: 1 },
    { tipo: "BAÑO", color: "bg-yellow-500", urgencia: 2 },
    { tipo: "CONSULTA", color: "bg-blue-500", urgencia: 2 },
    { tipo: "AGUA", color: "bg-green-500", urgencia: 3 },
  ];

  // ---------------------------
  // Cargar hospitales
  // ---------------------------
  useEffect(() => {
    const fetchHospitales = async () => {
      try {
        const { data } = await api.get("/hospitals");
        setHospitales(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error("Error cargando hospitales:", err);
      }
    };
    fetchHospitales();
  }, []);

  // ---------------------------
  // Cargar pacientes del hospital (¡CORREGIDO!)
  // ---------------------------
  const fetchPacientes = async () => {
    if (!hospitalld) return setPacientes([]);
    try {
      const { data } = await api.get(`/pacientes?hospitalld=${hospitalld}`);
      // La siguiente línea estaba comentada/fuera de lugar
      setPacientes(Array.isArray(data) ? data : []); 
    } catch (err) {
      console.error("Error cargando pacientes:", err);
      setPacientes([]);
    }
  };

  // ---------------------------
  // Cargar dispositivos del hospital
  // ---------------------------
  const fetchDevices = async () => {
    if (!hospitalld) return setTccActivos([]);
    try {
      const { data } = await api.get(`/devices/hospital/${hospitalld}`);
      if (!Array.isArray(data)) return;
      
      setTccActivos((prev) => {
        const mapPrev = new Map(prev.map((d) => [d.id, d]));
        const nuevos = data.map((d) => ({
          ...mapPrev.get(d.id), ...d,
        }));
        return nuevos;
      });
    } catch (err) {
      console.error("Error cargando dispositivos:", err);
      setTccActivos([]);
    }
  };

  // ---------------------------
  // Refrescar datos periódicamente
  // ---------------------------
  useEffect(() => {
    if (!hospitalld) return;
    fetchPacientes();
    fetchDevices();
    const interval = setInterval(() => {
      fetchPacientes();
      fetchDevices();
    }, 8000); // refresca cada 8s
    return () => clearInterval(interval);
  }, [hospitalld]);

  // ---------------------------
  // Crear dispositivo simulado
  // ---------------------------
  const crearSimulado = async () => {
    if (!hospitalld) return alert("Selecciona un hospital primero");
    try {
      await api.post("/devices/simulated", {
        hospitalld,
        nombre: `Simulado ${Date.now()}`,
      });
      fetchDevices();
    } catch (err) {
      console.error(err);
      alert("No se pudo crear el dispositivo");
    }
  }

  // ---------------------------
  // Encender/Apagar dispositivo
  // ---------------------------
  const toggleDispositivo = async (device) => {
    try {
      const nuevoEstado = !device.activo;
      await api.put(`/devices/${device.id}/encendido`, { encendido: nuevoEstado });
      setTccActivos((prev) =>
        prev.map((d) => (d.id === device.id ? { ...d, activo: nuevoEstado } : d))
      );
    } catch (err) {
      console.error(err);
      alert("No se pudo actualizar el dispositivo");
    }
  };

  // ---------------------------
  // Renombrar dispositivo
  // ---------------------------
  const renombrarDispositivo = async (deviceId) => {
    const nuevoNombre = prompt("Ingrese nuevo nombre del dispositivo:");
    if (!nuevoNombre) return;
    try {
      await api.put(`/devices/${deviceId}/nombre`, { nombre: nuevoNombre });
      fetchDevices();
    } catch (err) {
      console.error(err);
      alert("No se pudo renombrar el dispositivo");
    }
  };

  // ---------------------------
  // Borrar dispositivo
  // ---------------------------
  const borrarDispositivo = async (deviceId) => {
    if (!window.confirm("¿Estás seguro de borrar este dispositivo?")) return;
    try {
      await api.delete(`/devices/${deviceId}`);
      setTccActivos((prev) => prev.filter((d) => d.id !== deviceId));
    } catch (err) {
      console.error(err);
      alert("No se pudo borrar el dispositivo");
    }
  };

  // ---------------------------
  // Enviar alerta (Simulador)
  // ---------------------------
  const enviarAlerta = async (device, necesidad) => {
    if (!device.activo) return alert("El dispositivo debe estar encendido");
    if (!device.patientId) return alert("Este TCC no está vinculado a un paciente");
    
    // NOTA: Esta función es solo para el SIMULADOR.
    // El TCC real envía su propia alerta con su MAC Address.
    // Esta función envía el device.id numérico.
    // Necesitamos una lógica que decida qué ruta de alerta usar...
    // ... ¡PERO! El TCC real no usa esta página, así que está bien.

    const horaActual = new Date().toLocaleTimeString();
    setUltimaHora((prev) => ({ ...prev, [device.id]: horaActual }));
    
    try {
      // Si es simulado, envía el deviceId
      if (device.simulacion) {
        await api.post("/alerts", {
          deviceId: device.id, // ID numérico
          need: necesidad.tipo,
          urgency: necesidad.urgencia,
          patientId: device.patientId,
          timestamp: new Date(),
        });
      } else {
        // Si es real, envía la macAddress
        await api.post("/alerts", {
          macAddress: device.macAddress, // MAC Address
          need: necesidad.tipo,
          urgency: necesidad.urgencia,
          // El patientId lo deduce el backend
        });
      }
      alert(` Alerta enviada desde ${device.nombre}: ${necesidad.tipo} (${horaActual})`); 
    } catch (err) {
      console.error(err);
      alert(`Error al enviar alerta: ${err.response?.data?.message || err.message}`);
    }
  };

  // ============================
  // NUEVO: Conectar TCC Real (Función Corregida)
  // ============================
  const handleConectarTccReal = async () => {
    if (!hospitalld) {
      alert("Selecciona un hospital primero");
      return;
    }
    
    const macAddress = prompt("Ingresa el ID Físico (MAC Address) del TCC:\n(Lo ves en la pantalla LCD del dispositivo)");
    if (!macAddress) return; // Si el usuario cancela

    const nombre = prompt("Ingresa un nombre para este TCC (Ej: TCC Habitación 101):");
    if (!nombre) return; // Si el usuario cancela

    // Llamar a la función que registra en la API
    registrarTccReal({ macAddress, nombre, hospitalld });
  };

  const registrarTccReal = async ({ macAddress, nombre, hospitalld }) => {
    try {
      const { data: newDevice } = await api.post("/devices/connect", {
        macAddress, // <-- Clave correcta
        nombre,
        hospitalld,
      });
      
      // Añadir el nuevo TCC real a la lista
      setTccActivos((prev) => [...prev, newDevice]);
      
      alert(`Dispositivo real conectado: ${newDevice.nombre}`);
    } catch (err) {
      console.error("Error al conectar TCC real:", err);
      // Mostrar el error específico del backend (ej: "MAC ya registrada")
      alert(`No se pudo conectar: ${err.response?.data?.message || err.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-yellow-100 p-6 space-y-8">
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate("/dashboard-ceo")} // Asumo que vuelves a CEO
          className="px-3 py-2 bg-white shadow rounded-full hover:bg-gray-100"
        >
          <ArrowLeft className="text-yellow-700" size={22} />
        </button>
        <h1 className="text-2xl font-bold text-yellow-900">Simulador TCC</h1>
      </div>

      {/* Seleccionar hospital */}
      <div className="bg-white p-6 rounded-xl shadow mb-6">
        <h2 className="text-lg font-semibold text-yellow-700 mb-2">Selecciona Hospital</h2>
        <select
          value={hospitalld}
          onChange={(e) => setHospitalld(e.target.value)}
          className="w-full p-2 border rounded-lg"
        >
          <option value="">-- Selecciona --</option>
          {hospitales.map((h) => (
            <option key={h.id} value={h.id}>
              {h.nombre} {h.direccion && `(${h.direccion})`}
            </option>
          ))}
        </select>
        
        <button
          onClick={crearSimulado}
          className="mt-2 px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
        >
          Crear dispositivo simulado
        </button>
        
        {/* ----- BOTÓN CORREGIDO ----- */}
        <button
          onClick={handleConectarTccReal}
          className="mt-2 ml-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
        >
          Conectar TCC Real
        </button>
      </div>

      {/* Dispositivos */}
      <div className="bg-white p-6 rounded-xl shadow">
        <h2 className="text-lg font-semibold text-yellow-700 mb-4">Dispositivos TCC</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {tccActivos.length > 0 ? (
            tccActivos.map((tcc) => (
              <div key={tcc.id} className="p-4 border rounded-lg shadow flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-3 h-3 rounded-full ${
                          tcc.activo ? "bg-green-500" : "bg-red-500"
                        }`}
                      ></span>
                      <p className="font-semibold">{tcc.nombre}</p>
                    </div>
                    {ultimaHora[tcc.id] && (
                      <p className="text-sm text-gray-500">
                        Última alerta: {ultimaHora[tcc.id]}
                      </p>
                    )}
                    {tcc.patientId ? (
                      <p className="text-xs text-green-600">
                        Vinculado a paciente #{tcc.patientId}
                      </p>
                    ) : (
                      <p className="text-xs text-red-600">Sin paciente</p>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => toggleDispositivo(tcc)}
                      className={`px-2 py-1 text-white text-sm rounded hover:opacity-90 ${
                        tcc.activo ? "bg-gray-800" : "bg-green-500"
                      }`}
                    >
                      {tcc.activo ? "Apagar" : "Encender"}
                    </button>
                    <button
                      onClick={() => renombrarDispositivo(tcc.id)}
                      className="px-2 py-1 text-sm text-blue-600 hover:underline"
                    >
                      Renombrar
                    </button>
                    <button
                      onClick={() => borrarDispositivo(tcc.id)}
                      className="px-2 py-1 text-sm text-red-600 hover:underline"
                    >
                      Borrar
                    </button>
                  </div>
                </div>
                {/* Botones de alertas */}
                <div className="flex flex-col gap-1 mt-2">
                  {necesidades.map((n) => (
                    <button
                      key={n.tipo}
                      onClick={() => enviarAlerta(tcc, n)}
                      disabled={!tcc.activo || !tcc.patientId}
                      className={`py-2 text-white rounded-lg shadow hover:opacity-90 ${
                        n.color
                      } ${!tcc.activo || !tcc.patientId ? "opacity-40 cursor-not-allowed" : ""}`}
                    >
                      {n.tipo}
                    </button>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-3 text-center">
              No hay dispositivos en este hospital.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}