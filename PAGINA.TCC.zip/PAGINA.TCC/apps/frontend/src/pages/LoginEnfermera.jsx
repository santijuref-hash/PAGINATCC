import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import axios from "axios";
export default function LoginEnfermera() {
 const [usuario, setUsuario] = useState("");
 const [password, setPassword] = useState("");
 const [error, setError] = useState("");
 const navigate = useNavigate();
 const handleLogin = async (e) => {
 e.preventDefault();
 setError("");
 try {
 const res = await axios.post(
 "http://localhost:8080/users/login",
 { usuario, password },
 { withCredentials: true }
 );
 const user = res.data;
 // Permitir solo rol ENFERMERA (sin importar mayúsculas)
 if (!user.role || user.role.toUpperCase() !== "ENFERMERA") {
 setError("No tienes permisos de enfermera");
 return;
 }
 // Validar que tenga hospital asignado
 if (!user.hospitalld) {
 setError("Tu usuario no tiene hospital asignado");
 return;
 }
 // Guardar enfermera y su hospital en localStorage
 localStorage.setItem(
 "enfermeraLogueada",
 JSON.stringify({
 id: user.id,
 usuario: user.usuario,
 hospitalld: user.hospitalld,
 hospitalNombre: user.hospitalNombre || "Hospital asignado",
 })
 );
 // Redirigir al dashboard de enfermera
 navigate("/dashboard-enfermera");
 } catch (err) {
 console.error(err);
 if (err.response && err.response.data && err.response.data.message) {
 setError(err.response.data.message);
 } else {
 setError("Error al iniciar sesión. Verifica usuario y contraseña.");
 }
 }
};
 return (
 <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-brfrom-pink-50 to-pink-100">
 <Link
 to="/roles"
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all"
 >
 <ArrowLeft size={28} />
 </Link>
 <motion.div
 initial={{ opacity: 0, scale: 0.9 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ duration: 0.5 }}
 className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md"
 >
 <h2 className="text-3xl font-bold text-center text-pink-700 mb-6">
 Login Enfermera
 </h2>
 <form onSubmit={handleLogin} className="space-y-5">
 <div>
 <label className="block text-gray-700 font-medium">Usuario</label>
 <input
 type="text"
 value={usuario}
 onChange={(e) => setUsuario(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2focus:ring-pink-400 outline-none"
 placeholder="Ingresa tu usuario"
 required
 />
 </div>
 <div>
 <label className="block text-gray-700 font-medium">Contraseña</label>
 <input
 type="password"
 value={password}
 onChange={(e) => setPassword(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2focus:ring-pink-400 outline-none"
 placeholder="Ingresa tu contraseña"
 required
 />
 </div>
 {error && <p className="text-red-500 text-sm text-center">{error}</p>}
 <motion.button
 whileHover={{ scale: 1.05 }}
 whileTap={{ scale: 0.95 }}
 type="submit"
 className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-xl fontsemibold transition-all"
 >
 Ingresar
 </motion.button>
 </form>
 </motion.div>
 </div>
 );
}
