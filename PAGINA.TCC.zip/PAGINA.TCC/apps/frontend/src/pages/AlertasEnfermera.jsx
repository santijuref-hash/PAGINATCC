import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2 } from "lucide-react"; // Importar icono de basura
import api from "../services/api";

export default function AlertasEnfermera() {
  const navigate = useNavigate();
  const [hospital, setHospital] = useState(null);
  const [alertas, setAlertas] = useState([]);
  const [notas, setNotas] = useState({});

  useEffect(() => {
    
    const fetchAlertas = async () => {
      try {
        const enfermeraData = JSON.parse(localStorage.getItem("enfermeraLogueada"));
        if (!enfermeraData?.hospitalld) return;

        if (!hospital) { // Solo setear el hospital una vez
          setHospital({
            id: enfermeraData.hospitalld,
            nombre: enfermeraData.hospitalNombre,
          });
        }

        const res = await api.get(`/alerts/hospital/${enfermeraData.hospitalld}`);
        const alertasDesdeDB = res.data || [];
        
        // 1. Actualizar la LISTA de alertas
        setAlertas(alertasDesdeDB); 
        
        // 2. Actualizar las NOTAS de forma inteligente
        setNotas(notasAntiguas => {
          const notasNuevasDesdeDB = {};
          
          // Cargar las notas que vienen de la base de datos
          alertasDesdeDB.forEach(alerta => {
            if (alerta.nota) {
              notasNuevasDesdeDB[alerta.id] = alerta.nota;
            }
          });

          // --- ¡¡AQUÍ ESTABA EL ERROR!! ---
          // Esta es la línea corregida. 
          // Combina las notas de la DB con las que estás escribiendo.
          return { ...notasNuevasDesdeDB, ...notasAntiguas };

        });

      } catch (err) {
        console.error("Error al cargar alertas:", err);
      }
    };

    fetchAlertas();
    const interval = setInterval(fetchAlertas, 5000); // refresca cada 5s
    return () => clearInterval(interval);
  }, [hospital]); // <--- Añadí 'hospital' aquí para que sea más estable

  const handleNotaChange = (id, value) => {
    setNotas({ ...notas, [id]: value });
  };

  // ----- FUNCIÓN CORREGIDA -----
  const guardarNota = async (alertaId) => {
    try {
      const nota = notas[alertaId] || ""; // Obtener la nota del estado
      // Usar la nueva ruta PUT para ACTUALIZAR la alerta
      await api.put(`/alerts/${alertaId}/nota`, { nota: nota });
      alert("Nota guardada");
    } catch (err) {
      console.error("Error al guardar nota:", err);
      alert("No se pudo guardar la nota");
    }
  };

  // ----- FUNCIÓN NUEVA -----
  const borrarAlerta = async (alertaId) => {
    if (!window.confirm("¿Estás seguro de eliminar esta alerta?")) {
      return;
    }
    try {
      // Usar la nueva ruta DELETE
      await api.delete(`/alerts/${alertaId}`);
      // Quitar la alerta del estado local (la lista en pantalla)
      setAlertas(alertas.filter(a => a.id !== alertaId));
    } catch (err) {
      console.error("Error al eliminar alerta:", err);
      alert("No se pudo eliminar la alerta");
    }
  };

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("/dashboard-enfermera")} className="flex items-center gap-2 px-3 py-2 bg-white shadow rounded-full hover:bg-gray-100 transition">
          <ArrowLeft size={22} />
        </button>
        <h1 className="text-2xl font-bold text-gray-800">Alertas del Hospital</h1>
      </div>

      {alertas.length === 0 ? (
        <p>No hay alertas por el momento</p>
      ) : (
        <ul className="space-y-4">
          {alertas.map((a) => (
            <li key={a.id} className="bg-white p-4 rounded-lg shadow">
              {/* --- BOTÓN DE BORRAR AÑADIDO --- */}
              <button 
                onClick={() => borrarAlerta(a.id)}
                className="float-right text-red-500 hover:text-red-700"
              >
                <Trash2 size={18} />
              </button>
              <p><strong>Paciente:</strong> {a.patient ? a.patient.nombre : `ID: ${a.patientId}`}</p>
              <p><strong>Urgencia:</strong> {a.urgency}</p>
              <p><strong>Necesidad:</strong> {a.need}</p>
              <p><strong>Hora:</strong> {new Date(a.timestamp).toLocaleString()}</p>
              
              <textarea
                value={notas[a.id] || ""}
                onChange={(e) => handleNotaChange(a.id, e.target.value)}
                placeholder="Agregar nota..."
                className="w-full p-2 border rounded mt-2"
              />
              <button
                onClick={() => guardarNota(a.id)}
                className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Guardar Nota
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}