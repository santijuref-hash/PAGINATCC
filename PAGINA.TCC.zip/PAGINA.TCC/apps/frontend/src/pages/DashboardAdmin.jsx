import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import axios from "axios";
export default function DashboardAdmin() {
 const navigate = useNavigate();
 const [adminData, setAdminData] = useState(null);
 const [enfermeras, setEnfermeras] = useState([]);
 const [nuevaEnfermera, setNuevaEnfermera] = useState({ usuario: "", password: "" });
 const api = axios.create({ baseURL: "http://localhost:8080", withCredentials: true });
 useEffect(() => {
 const admin = JSON.parse(localStorage.getItem("usuarioAdmin"));
 if (!admin) { navigate("/login-admin"); return; }
 setAdminData(admin);
 if (!admin.hospitalld) {
 alert("No tienes hospital asignado. Contacta al administrador superior.");
 return;
 }
 fetchEnfermeras(admin.hospitalld);
 }, [navigate]);
 const fetchEnfermeras = async (hospitalld) => {
 try {
 const res = await api.get(`/users?role=ENFERMERA&hospitalld=${hospitalld}`);
 setEnfermeras(res.data || []);
 } catch (err) {
 console.error("Error cargando enfermeras:", err);
 alert("Error cargando enfermeras");
 }
 };
 const handleChange = (e) => setNuevaEnfermera({ ...nuevaEnfermera, [e.target.name]:
e.target.value });
 const registrarEnfermera = async () => {
 if (!nuevaEnfermera.usuario || !nuevaEnfermera.password) {
 alert("Completa usuario y contraseña");
 return;
 }
 if (!adminData?.hospitalld) {
 alert("No puedes registrar enfermeras sin hospital asignado");
 return;
 }
 try {
 const res = await api.post("/users", {
 usuario: nuevaEnfermera.usuario,
 password: nuevaEnfermera.password,
 hospitalld: adminData.hospitalld,
 role: "ENFERMERA", // rol actualizado para login
 });
 setEnfermeras([...enfermeras, res.data]);
 setNuevaEnfermera({ usuario: "", password: "" });
 } catch (err) {
 console.error("Error registrando enfermera:", err);
 alert(err.response?.data?.message || "No se pudo registrar la enfermera.");
 }
 };
 const eliminarEnfermera = async (id) => {
 try {
 await api.delete(`/users/${id}`);
 setEnfermeras(enfermeras.filter(e => e.id !== id));
 } catch (err) {
 console.error("Error eliminando enfermera:", err);
 alert("No se pudo eliminar la enfermera.");
 }
 };
 return (
 <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-indigo-100 p-6">
 {/* Header */}
 <div className="flex justify-between items-center mb-8">
 <div className="flex items-center gap-3">
 <button onClick={() => navigate("/roles")} className="flex items-center gap-2 px-3py-2 bg-white shadow rounded-full hover:bg-gray-100 transition">
 <ArrowLeft className="text-indigo-700" size={22} />
 <span className="font-bold text-xl text-indigo-900">Panel Admin</span>
 </button>
 </div>
 <div className="flex gap-3">
 <button onClick={() => navigate("/estadisticas")} className="px-4 py-2 bg-green500 text-white rounded-lg shadow hover:bg-green-600 transition">Estadísticas</button>
 <button onClick={() => { localStorage.removeItem("usuarioAdmin"); navigate("/loginadmin"); }} className="px-4 py-2 bg-indigo-500 text-white rounded-lg shadow hover:bgindigo-600 transition">Cerrar sesión</button>
 </div>
 </div>
 {/* Info hospital */}
 <div className="bg-white shadow rounded-xl p-4 mb-6">
 <p className="text-gray-700"><span className="font-semibold text-indigo700">Hospital:</span> {adminData?.hospitalNombre || "No asignado"}</p>
 </div>
 {/* Registro de enfermeras */}
 <div className="bg-white rounded-xl shadow p-6 mb-8">
 <h2 className="text-lg font-semibold text-indigo-700 mb-4">RegistrarEnfermera</h2>
 <input type="text" name="usuario" value={nuevaEnfermera.usuario}
onChange={handleChange} placeholder="Usuario" className="w-full mb-3 p-2 borderrounded-lg" />
 <input type="password" name="password" value={nuevaEnfermera.password}
onChange={handleChange} placeholder="Contraseña" className="w-full mb-3 p-2border rounded-lg" />
 <button onClick={registrarEnfermera} className="w-full py-2 bg-indigo-500 textwhite rounded-lg hover:bg-indigo-600 transition">Registrar</button>
 </div>
 {/* Listado de enfermeras */}
 <div className="bg-white rounded-xl shadow p-6">
 <h2 className="text-lg font-semibold text-indigo-700 mb-4">EnfermerasRegistradas</h2>
 {enfermeras.length === 0 ? <p className="text-gray-500">Aún no hay enfermeras registradas.</p> : <ul className="space-y-3">
 {enfermeras.map(e => (
 <li key={e.id} className="flex justify-between items-center bg-indigo-50 p-3rounded-lg shadow-sm">
 <div>
 <p className="font-semibold">{e.usuario}</p>
 <p className="text-sm text-gray-600">Hospital:{adminData?.hospitalNombre}</p>
 </div>
 <button onClick={() => eliminarEnfermera(e.id)} className="px-3 py-1 text-smbg-red-500 text-white rounded-lg hover:bg-red-600 transition">Eliminar</button>
 </li>
 ))}
 </ul>
 }
 </div>
 </div>
 );
}
