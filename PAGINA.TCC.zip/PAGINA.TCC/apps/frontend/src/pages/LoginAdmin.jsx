import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import axios from "axios";
export default function LoginAdmin() {
 const [usuario, setUsuario] = useState("");
 const [password, setPassword] = useState("");
 const [error, setError] = useState("");
 const navigate = useNavigate();
 const handleLogin = async (e) => {
 e.preventDefault();
 setError("");
 try {
 const res = await axios.post(
 "http://localhost:8080/users/login",
 { usuario, password },
 { withCredentials: true }
 );
 const adminLogueado = res.data;
 if (!adminLogueado.hospitalld) {
 setError("El administrador no tiene hospital asignado");
 return;
 }
 // Guardar sesión completa con hospitalId y nombre si existe
 localStorage.setItem(
 "usuarioAdmin",
 JSON.stringify({
 ...adminLogueado,
 hospitalNombre: adminLogueado.hospitalNombre || "No asignado",
 })
 );
 navigate("/dashboard-admin");
 } catch (err) {
   console.error(err);
 setError(
 err.response?.data?.message ||
 "Error al iniciar sesión. Revisa usuario y contraseña."
 );
 }
 };
 return (
 <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-brfrom-blue-50 to-blue-100">
 <Link
 to="/roles"
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all"
 >
 <ArrowLeft size={28} />
 </Link>
 <motion.div
 initial={{ opacity: 0, scale: 0.9 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ duration: 0.5 }}
 className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md"
 >
 <h2 className="text-3xl font-bold text-center text-blue-700 mb-6">
 Login Administrador
 </h2>
 <form onSubmit={handleLogin} className="space-y-5">
 <div>
 <label className="block text-gray-700 font-medium">Usuario</label>
 <input
 type="text"
 value={usuario}
 onChange={(e) => setUsuario(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2
focus:ring-blue-400 outline-none"
 placeholder="Ingresa tu usuario"
 required
 />
 </div>
 <div>
 <label className="block text-gray-700 font-medium">Contraseña</label>
 <input
 type="password"
 value={password}
 onChange={(e) => setPassword(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2
focus:ring-blue-400 outline-none"
 placeholder="Ingresa tu contraseña"
 required
 />
 </div>
 {error && <p className="text-red-500 text-sm text-center">{error}</p>}
 <motion.button
 whileHover={{ scale: 1.05 }}
 whileTap={{ scale: 0.95 }}
 type="submit"
 className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl fontsemibold transition-all"
 >
 Ingresar
 </motion.button>
 </form>
 </motion.div>
 </div>
 );
}
