// src/pages/DashboardPaciente.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
export default function DashboardPaciente() {
 const navigate = useNavigate();
 const [paciente, setPaciente] = useState(null);
 const [loading, setLoading] = useState(true);
 useEffect(() => {
 const fetchPacienteCompleto = async () => {
 const pacienteLogueado = JSON.parse(localStorage.getItem("usuarioPaciente"));
 if (!pacienteLogueado) {
 navigate("/login-paciente");
 return;
 }
 let tccNombre = "Sin asignar";
 let patologiaNombre = "No asignada";
  let hospitalNombre = "Sin asignar";
 try {
 if (pacienteLogueado.tccId) {
 const resTCC = await fetch(`http://localhost:8080/devices/$
{pacienteLogueado.tccId}`);
 if (resTCC.ok) {
 const tccData = await resTCC.json();
 tccNombre = tccData.nombre;
 }
 }
 if (pacienteLogueado.patologiaId) {
 const resPat = await fetch(`http://localhost:8080/patologias/$
{pacienteLogueado.patologiaId}`);
 if (resPat.ok) {
 const patData = await resPat.json();
 patologiaNombre = patData.name;
 }
 }
 if (pacienteLogueado.hospitalld) {
 const resHosp = await fetch(`http://localhost:8080/hospitales/$
{pacienteLogueado.hospitalId}`);
 if (resHosp.ok) {
 const hospData = await resHosp.json();
 hospitalNombre = hospData.nombre;
 }
 }
 } catch (err) {
 console.error("Error cargando datos relacionados:", err);
 }
 const pacienteCompleto = {
 ...pacienteLogueado,
 tccNombre,
 patologiaNombre,
 hospitalNombre,
 };
 setPaciente(pacienteCompleto);
 localStorage.setItem("usuarioPaciente", JSON.stringify(pacienteCompleto));
 setLoading(false);
 };
 fetchPacienteCompleto();
 }, [navigate]);
 const cerrarSesion = () => {
 localStorage.removeItem("usuarioPaciente");
 navigate("/roles");
 };
 if (loading) return <p className="p-6 text-center">Cargando datos...</p>;
 if (!paciente) return null;
 return (
 <div className="min-h-screen bg-gradient-to-br from-purple-50 to-purple-100 p-6">
 {/* Header */}
 <div className="flex justify-between items-center mb-8">
 <button
 onClick={() => navigate("/login-paciente")}
 className="flex items-center gap-2 px-3 py-2 bg-white shadow rounded-full
hover:bg-gray-100 transition"
 >
 <ArrowLeft className="text-purple-700" size={22} />
 </button>
 <h1 className="text-3xl font-bold text-purple-900">Panel del Paciente</h1>
 <button
 onClick={cerrarSesion}
 className="px-4 py-2 bg-purple-600 text-white rounded-lg shadow hover:bgpurple-700 transition"
 >
 Cerrar sesión
 </button>
 </div>
 {/* Card de datos */}
 <div className="bg-white rounded-xl shadow-lg p-6 max-w-lg mx-auto space-y-2">
 <h2 className="text-xl font-semibold text-purple-700 mb-4">
 Mis datos
 </h2>
 <p>
 <span className="font-semibold">Nombre:</span> {paciente.nombre}
 </p>
 <p>
 <span className="font-semibold">DNI:</span> {paciente.dni}
 </p>
 <p>
 <span className="font-semibold">Edad:</span> {paciente.edad || "N/A"}
 </p>
 <p>
 <span className="font-semibold">TCC:</span> {paciente.tccNombre}
 </p>
 <p>
 <span className="font-semibold">Patología:</span> {paciente.patologiaNombre}
 </p>
 <p>
 <span className="font-semibold">Hospital:</span> {paciente.hospitalNombre}
 </p>
 </div>
 </div>
 );
}
