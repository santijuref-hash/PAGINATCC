import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Edit2, Check, X } from "lucide-react";
export default function DashboardEnfermera() {
 const navigate = useNavigate();
 const [enfermera, setEnfermera] = useState(null);
 const [pacientes, setPacientes] = useState([]);
 const [tccs, setTccs] = useState([]);
 const [alertas, setAlertas] = useState([]);
 // Estados de edición
 const [editMode, setEditMode] = useState(false);
 const [nombreEdit, setNombreEdit] = useState("");
 const [hospitalEdit, setHospitalEdit] = useState("");
 const [sectorEdit, setSectorEdit] = useState("");
 useEffect(() => {
 const enfermeraData = JSON.parse(localStorage.getItem("enfermeraLogueada"));
 if (!enfermeraData) return navigate("/");
 // Usar siempre lo que esté en localStorage (que ya puede venir editado)
 setEnfermera(enfermeraData);
 setNombreEdit(enfermeraData.nombre || "");
 setHospitalEdit(enfermeraData.hospitalNombre || "");
 setSectorEdit(enfermeraData.sector || "");
 const hospitalld = enfermeraData.hospitalld;
 let intervalTCC, intervalAlertas;
 // Cargar pacientes
 fetch(`http://localhost:8080/pacientes?hospitalld=${hospitalld}`)
 .then(res => res.json())
 .then(data => setPacientes(data))
 .catch(err => console.error("Error pacientes:", err));
 // Polling TCC cada 5 segundos
 const fetchTCCs = async () => {
 try {
 const res = await fetch(`http://localhost:8080/devices/hospital/${hospitalld}`);
 const data = await res.json();
 setTccs(data);
 } catch (err) {
 console.error("Error TCCs:", err);
 }
 };
 fetchTCCs();
 intervalTCC = setInterval(fetchTCCs, 5000);
 // Polling alertas cada 5 segundos
 const fetchAlertas = async () => {
 try {
 const res = await fetch(`http://localhost:8080/alerts/hospital/${hospitalld}`);
 const data = await res.json();
 setAlertas(data || []);
 } catch (err) {
 console.error("Error alertas:", err);
 }
 };
 fetchAlertas();
 intervalAlertas = setInterval(fetchAlertas, 5000);
 return () => {
 clearInterval(intervalTCC);
 clearInterval(intervalAlertas);
 };
 }, [navigate]);
 const handleLogout = () => {
 localStorage.removeItem("enfermeraLogueada");
 navigate("/");
 };
 const handleSave = () => {
 const updated = {
 ...enfermera,
 nombre: nombreEdit,
 hospitalNombre: hospitalEdit,
 sector: sectorEdit,
 };
 setEnfermera(updated);
 // Guardar en localStorage para persistir cambios en refresco o nuevo login
 localStorage.setItem("enfermeraLogueada", JSON.stringify(updated));
 setEditMode(false);
 // Opcional: guardar en backend si tenés endpoint
 // api.put(`/enfermeras/${enfermera.id}`, updated);
 };
 return (
 <div className="min-h-screen bg-gradient-to-br from-pink-50 to-pink-100 p-6">
 {/* Barra superior */}
 <div className="flex items-center justify-between mb-8">
 <div className="flex items-center gap-3">
 <button
 onClick={() => navigate("/")}
 className="px-3 py-2 bg-white shadow rounded-full hover:bg-gray-100"
 >
 <ArrowLeft className="text-pink-700" size={22} />
 </button>
 <h1 className="text-2xl font-bold text-pink-700 tracking-wide">
 Panel de enfermera
 </h1>
 </div>
 <div className="flex gap-3">
 <button
 onClick={() => navigate("/registros-enfermera")}
 className="px-4 py-2 bg-purple-600 text-white rounded-xl shadow hover:bgpurple-700"
 >
 Registros
 </button>
 <button
 onClick={() => navigate("/alertas-enfermera")}
 className="px-4 py-2 bg-red-500 text-white rounded-xl shadow hover:bg-red-600"
 >
 Alertas
 </button>
 <button
 onClick={handleLogout}
 className="px-4 py-2 bg-pink-600 text-white rounded-xl shadow hover:bg-pink700"
 >
 Cerrar sesión
 </button>
 </div>
 </div>
 {/* Info enfermera */}
 <div className="relative bg-white shadow rounded-xl p-6 mb-8">
 <button
 onClick={() => setEditMode(!editMode)}
 className="absolute top-4 right-4 text-pink-500 hover:text-pink-700"
 >
 {editMode ? <X size={20} /> : <Edit2 size={20} />}
 </button>
 <h2 className="text-lg font-semibold text-pink-700 mb-4">Bienvenida</h2>
 {editMode ? (
 <div className="space-y-2">
 <div>
 <label className="block text-gray-700 font-semibold">Nombre:</label>
 <input
 type="text"
 value={nombreEdit}
 onChange={(e) => setNombreEdit(e.target.value)}
 className="mt-1 p-2 border rounded w-full"
 />
 </div>
 <div>
 <label className="block text-gray-700 font-semibold">Hospital:</label>
 <input
 type="text"
 value={hospitalEdit}
 onChange={(e) => setHospitalEdit(e.target.value)}
 className="mt-1 p-2 border rounded w-full"
 />
 </div>
 <div>
 <label className="block text-gray-700 font-semibold">Sector:</label>
 <input
 type="text"
 value={sectorEdit}
 onChange={(e) => setSectorEdit(e.target.value)}
 className="mt-1 p-2 border rounded w-full"
 />
 </div>
 <button
 onClick={handleSave}
 className="mt-3 px-4 py-2 bg-pink-600 text-white rounded shadow hover:bgpink-700"
 >
 <Check size={16} className="inline mr-1" /> Guardar
 </button>
 </div>
 ) : (
 <div>
 <p className="text-gray-700">
 <span className="font-semibold">Nombre:</span> {enfermera?.nombre}
 </p>
 <p className="text-gray-700">
 <span className="font-semibold">Hospital:</span>
{enfermera?.hospitalNombre}
 </p>
 <p className="text-gray-700">
 <span className="font-semibold">Sector:</span> {enfermera?.sector || "-"}
 </p>
 </div>
 )}
 </div>
 {/* Resumen rápido */}
 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
 <div className="bg-purple-100 p-4 rounded-xl shadow">
 <p className="text-sm text-gray-600">Pacientes</p>
 <p className="text-2xl font-bold text-purple-700">{pacientes.length}</p>
 </div>
 <div className="bg-red-100 p-4 rounded-xl shadow">
 <p className="text-sm text-gray-600">Alertas activas</p>
 <p className="text-2xl font-bold text-red-700">{alertas.length}</p>
 </div>
 <div className="bg-pink-100 p-4 rounded-xl shadow">
 <p className="text-sm text-gray-600">TCC disponibles</p>
 <p className="text-2xl font-bold text-pink-700">{tccs.filter(t => t.activo).length}</p>
 </div>
 </div>
 </div>
 );
}
