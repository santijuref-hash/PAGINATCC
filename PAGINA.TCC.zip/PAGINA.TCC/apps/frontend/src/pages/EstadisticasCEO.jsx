import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import api from "../services/api";
import {
 BarChart,
 Bar,
 XAxis,
 YAxis,
 Tooltip,
 ResponsiveContainer,
 Legend,
} from "recharts";
export default function EstadisticasCEO() {
 const navigate = useNavigate();
 const [hospitales, setHospitales] = useState([]);
 const [hospitalId, setHospitalId] = useState("");
 const [estadisticas, setEstadisticas] = useState([]);
 const [metrica, setMetrica] = useState("total_tcc"); // Métrica seleccionada
 // Cargar hospitales
 useEffect(() => {
 api.get("/hospitals")
 .then((res) => setHospitales(res.data))
 .catch((err) => console.error(err));
 }, []);
 // Cargar estadísticas
 const fetchStats = async () => {
 try {
 const query = hospitalld ? `?hospitalld=${hospitalld}` : "";
 const res = await api.get(`/stats${query}`);
 setEstadisticas(res.data);
 } catch (err) {
 console.error(err);
 }
 };
 useEffect(() => {
 fetchStats();
 }, [hospitalld]);
 return (
 <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-blue-100 space-y6">
 {/* Header */}
 <div className="flex items-center justify-between">
 <button
 onClick={() => navigate("/dashboard-ceo")}
 className="flex items-center gap-2 px-3 py-2 bg-white shadow rounded-full
hover:bg-gray-100 transition"
 >
 <ArrowLeft size={22} className="text-blue-700" />
 Volver
 </button>
 <h1 className="text-3xl font-bold text-blue-900">Estadísticas TCC</h1>
 </div>
 {/* Selector de hospital */}
 <div className="flex flex-col md:flex-row gap-4">
 <select
 value={hospitalId}
 onChange={(e) => setHospitalld(e.target.value)}
 className="border p-2 rounded-lg w-full md:w-64"
 >
 <option value="">Todos los hospitales</option>
 {hospitales.map((h) => (
 <option key={h.id} value={h.id}>
 {h.name} {h.location && `(${h.location})`}
 </option>
 ))}
 </select>
 {/* Selector de métrica */}
 <select
 value={metrica}
 onChange={(e) => setMetrica(e.target.value)}
 className="border p-2 rounded-lg w-full md:w-64"
 >
 <option value="total_tcc">Total TCC</option>
 <option value="activos">TCC Activos</option>
 <option value="dados_alta">TCC Dados de Alta</option>
 <option value="pacientes_atendidos">Pacientes Atendidos</option>
 <option value="tiempo_respuesta">Tiempo de Respuesta (min)</option>
 </select>
 </div>
 {/* Gráfico */}
 <div className="bg-white shadow rounded-lg p-6">
 <h2 className="text-xl font-semibold text-blue-700 mb-4">
 {metrica.replace(/_/g, " ").toUpperCase()} por hospital
 </h2>
 <ResponsiveContainer width="100%" height={300}>
 <BarChart data={estadisticas} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
 <XAxis dataKey="hospital" />
 <YAxis />
 <Tooltip />
 <Legend />
 <Bar dataKey={metrica} fill="#3b82f6" name={metrica.replace(/_/g, "").toUpperCase()} />
 </BarChart>
 </ResponsiveContainer>
 </div>
 </div>
 );
}
