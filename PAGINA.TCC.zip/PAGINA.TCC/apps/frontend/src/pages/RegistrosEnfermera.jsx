import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
export default function RegistrosEnfermera() {
 const navigate = useNavigate();
 const [hospital, setHospital] = useState(null);
 const [pacientes, setPacientes] = useState([]);
 const [patologias, setPatologias] = useState([]);
 const [tccs, setTccs] = useState([]);
 const [nuevoPaciente, setNuevoPaciente] = useState({
 nombre: "",
 dni: "",
 edad: "",
 patologiaId: "",
 tccId: "",
 });
 const [nuevaPatologia, setNuevaPatologia] = useState({ name: "", level: "1" });
 const [loading, setLoading] = useState(false);
 const [error, setError] = useState("");
 const [success, setSuccess] = useState("");
 useEffect(() => {
 let interval;
 async function cargarDatos() {
 try {
 setLoading(true);
 const enfermeraData = JSON.parse(localStorage.getItem("enfermeraLogueada"));
 if (!enfermeraData?.hospitalld) return setError("No se encontró hospital asociado.");
 setHospital({ id: enfermeraData.hospitalld, nombre: enfermeraData.hospitalNombre });
 // Pacientes
const resPacientes = await fetch(`http://localhost:8080/pacientes?hospitalld=${enfermeraData.hospitalld}`);
const pacientesData = await resPacientes.json();
// --- INICIO DE LA CORRECCIÓN (Problema 1) ---
// Mapeamos los datos del backend a los nombres que usa el frontend
const pacientesMapeados = pacientesData.map(p => ({
 ...p,
 patologiaNombre: p.patologia || "No asignada", // Mapea p.patologia ->p.patologiaNombre
 tccNombre: p.tcc || "Sin asignar" // Mapea p.tcc -> p.tccNombre
}));
setPacientes(pacientesMapeados);
// --- FIN DE LA CORRECCIÓN ---
 // Patologías
 const resPatologias = await fetch(`http://localhost:8080/patologias?hospitalld=${enfermeraData.hospitalld}`);
 setPatologias(await resPatologias.json());
 // TCCs
 const fetchTCCs = async () => {
 const res = await fetch(`http://localhost:8080/devices/hospital/${enfermeraData.hospitalld}`);
 setTccs(await res.json());
 };
 await fetchTCCs();
 interval = setInterval(fetchTCCs, 5000);
 } catch (err) {
 console.error(err);
 setError("Error al cargar datos del servidor");
 } finally {
 setLoading(false);
 }
 }
 cargarDatos();
 return () => clearInterval(interval);
 }, []);
 // --------------------------- Patologías ---------------------------
 const registrarPatologia = async () => {
 if (!nuevaPatologia.name.trim()) return setError("El nombre es obligatorio.");
 if (!hospital?.id) return setError("No se encontró hospital.");
 try {
 const res = await fetch("http://localhost:8080/patologias", {
 method: "POST",
 headers: { "Content-Type": "application/json" },
 body: JSON.stringify({ ...nuevaPatologia, hospitalld: hospital.id }),
 });
 const patologiaCreada = await res.json();
 setPatologias([...patologias, patologiaCreada]);
 setNuevaPatologia({ name: "", level: "1" });
 setError("");
 setSuccess("Patología registrada");
 } catch (err) {
 console.error(err);
 setError(err.message);
 }
 };
 const eliminarPatologia = async (id) => {
 try {
 await fetch(`http://localhost:8080/patologias/${id}`, { method: "DELETE" });
 setPatologias(patologias.filter(p => p.id !== id));
 setSuccess("Patología eliminada");
 } catch (err) {
 console.error(err);
 setError("Error al eliminar patología");
 }
 };
 // --------------------------- Pacientes ---------------------------
 const handleChangePaciente = (e) => {
 // --- INICIO DE LA CORRECCIÓN ---

 // Mueve estas líneas adentro de las llaves
 setNuevoPaciente({ ...nuevoPaciente, [e.target.name]: e.target.value });
 setError("");
 setSuccess("");
 // --- FIN DE LA CORRECCIÓN ---
};
 const registrarPaciente = async () => {
 // --- INICIO DE LA CORRECCIÓN ---
 // 1. DESTRUCTRURAR CON LOS NOMBRES CORRECTOS DEL ESTADO (con 'Id')
 const { nombre, dni, edad, patologiaId, tccId } = nuevoPaciente;
 // 2. VALIDAR USANDO ESOS MISMOS NOMBRES (con 'Id')
 if (!nombre || !dni || !patologiaId || !tccId) {
 setError("Completa todos los campos");
 return;
 }
 if (!hospital?.id) {
 setError("No se encontró hospital. Espera a que carguen los datos.");
 return;
 }
 if (pacientes.some(p => p.dni === dni)) {
 setError("Ya existe paciente con ese DNI");
 return;
 }
 try {
 const res = await fetch("http://localhost:8080/pacientes", {
 method: "POST",
 headers: { "Content-Type": "application/json" },
 // 3. ENVIAR AL BACKEND CON LOS NOMBRES QUE ESPERA (con 'ld')
 body: JSON.stringify({
 nombre,
 dni,
 edad,
 patologiald: patologiaId, // Mapeo de 'Id' a 'ld'
 tccld: tccId, // Mapeo de 'Id' a 'ld'
 hospitalld: hospital.id // <--- CORREGIDO
 }),
 });
 const data = await res.json(); // 'data' es el newPatient que ya tiene 'patologia' y 'tcc'
if (!res.ok) throw new Error(data.message || "Error al crear paciente");
// --- INICIO DE LA CORRECCIÓN (Consistencia) ---
// Usamos los campos 'patologia' y 'tcc' que vienen del backend
const pacienteConNombres = {
 ...data,
 patologiaNombre: data.patologia || "No asignada",
 tccNombre: data.tcc || "Sin asignar",
};
// --- FIN DE LA CORRECCIÓN ---
 setPacientes([...pacientes, pacienteConNombres]);
 setNuevoPaciente({ nombre: "", dni: "", edad: "", patologiaId: "", tccId: "" });
 setError("");
 setSuccess("Paciente registrado correctamente");
 } catch (err) {
 console.error(err);
 setError(err.message);
 }
 };
 const eliminarPaciente = async (id) => {
 try {
 await fetch(`http://localhost:8080/pacientes/${id}`, { method: "DELETE" });
 setPacientes(pacientes.filter(p => p.id !== id));
 setSuccess("Paciente eliminado");
 } catch (err) {
 console.error(err);
 setError("Error al eliminar paciente");
 }
 };
 const toggleTCC = async (tccId) => {
 const tcc = tccs.find(t => t.id === tccId);
 if (!tcc) return;
 try {
 const nuevoEstado = !tcc.activo;
 await fetch(`http://localhost:8080/devices/${tccId}/encendido`, {
 method: "PUT",
 headers: { "Content-Type": "application/json" },
 body: JSON.stringify({ encendido: nuevoEstado }),
 });
 setTccs(tccs.map(t => t.id === tccId ? { ...t, activo: nuevoEstado } : t));
 setPacientes(pacientes.map(p => p.tccId === tccId ? { ...p, tccActivo: nuevoEstado } :
p));
 } catch (err) {
 console.error(err);
 alert("No se pudo actualizar el TCC");
 }
 };
 if (loading) return <p className="p-6 text-center">Cargando datos...</p>;
 const nivelColor = (nivel) =>
 nivel === "1" ? "bg-red-100 text-red-700" :
 nivel === "2" ? "bg-yellow-100 text-yellow-700" :
 nivel === "3" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700";
 return (
 <div className="min-h-screen bg-gradient-to-br from-pink-50 to-pink-100 p-6 space-y10">
 <div className="flex justify-between items-center mb-8">
 <div className="flex items-center gap-3">
 <button onClick={() => navigate("/dashboard-enfermera")} className="flex itemscenter gap-2 px-3 py-2 bg-white shadow rounded-full hover:bg-gray-100 transition">
 <ArrowLeft className="text-pink-700" size={22} />
 </button>
 <h1 className="text-2xl md:text-3xl font-bold text-pink-900">Registros de
Enfermera</h1>
 </div>
 </div>
 {error && <div className="p-2 bg-red-100 text-red-600 rounded">{error}</div>}
 {success && <div className="p-2 bg-green-100 text-green-600
rounded">{success}</div>}
 {/* Patologías */}
 <div className="bg-white rounded-xl shadow p-6">
 <h2 className="text-lg font-semibold text-pink-700 mb-4">Gestionar
Patologías</h2>
 <div className="flex gap-2 mb-3">
 <input
 type="text"
 placeholder="Nombre de patología"
 value={nuevaPatologia.name}
 onChange={(e) => setNuevaPatologia({ ...nuevaPatologia, name: e.target.value })}
 className="flex-1 p-2 border rounded-lg"
 />
 <select value={nuevaPatologia.level} onChange={(e) => setNuevaPatologia({
...nuevaPatologia, level: e.target.value })} className="p-2 border rounded-lg">
 <option value="1">Nivel 1 (Alta prioridad)</option>
 <option value="2">Nivel 2</option>
 <option value="3">Nivel 3 (Baja)</option>
 </select>
 <button onClick={registrarPatologia} className="px-4 py-2 bg-pink-500 text-white
rounded-lg hover:bg-pink-600 transition">Agregar</button>
 </div>
 </div>
 {/* Pacientes */}
 <div className="bg-white rounded-xl shadow p-6">
 <h2 className="text-lg font-semibold text-pink-700 mb-4">Registrar Paciente</h2>
 <div className="grid gap-3">
 <input type="text" name="nombre" value={nuevoPaciente.nombre}
onChange={handleChangePaciente} placeholder="Nombre completo *" className="p-2
border rounded-lg" />
 <input type="text" name="dni" value={nuevoPaciente.dni}
onChange={handleChangePaciente} placeholder="DNI *" className="p-2 border
rounded-lg" />
 <input type="number" name="edad" value={nuevoPaciente.edad}
onChange={handleChangePaciente} placeholder="Edad" className="p-2 border
rounded-lg" />
 <select name="patologiaId" value={nuevoPaciente.patologiaId}
onChange={handleChangePaciente} className="p-2 border rounded-lg">
 <option value="">Seleccionar patología *</option>
 {patologias.map((p) => (<option key={p.id} value={p.id}>{p.name} (Nivel
{p.level})</option>))}
 </select>
 <select name="tccId" value={nuevoPaciente.tccId}
onChange={handleChangePaciente} className="p-2 border rounded-lg">
 <option value="">Seleccionar TCC *</option>
 {tccs.map((t) => (<option key={t.id} value={t.id}>{t.nombre} ({t.activo ?
"Encendido" : "Apagado"})</option>))}
 </select>
 <button onClick={registrarPaciente} className="py-2 bg-pink-500 text-white
rounded-lg hover:bg-pink-600">Registrar Paciente</button>
 </div>
 {/* ---------------- Renderizado de tarjetas actualizado ---------------- */}
 <ul className="mt-4 space-y-2">
 {pacientes.map((p) => (
 <li key={p.id} className="flex justify-between items-center bg-pink-50 p-2rounded-lg">
 <div>
 {p.nombre} - Patología: {p.patologiaNombre || "No asignada"} - TCC:
{p.tccNombre || "Sin asignar"}
 </div>
 <div className="flex items-center gap-2">
 {p.tccActivo !== undefined && (
 <button
 onClick={() => toggleTCC(p.tccId)}
 className={`px-2 py-1 text-sm rounded ${p.tccActivo ? "bg-gray-800 text-white" : "bg-green-500 text-white"}`}
 >
 {p.tccActivo ? "Apagar" : "Encender"}
 </button>
 )}
 <button onClick={() => eliminarPaciente(p.id)} className="text-sm text-red-600 hover:underline">Eliminar</button>
 </div>
 </li>
 ))}
 </ul>
 </div>
 </div>
 );
}