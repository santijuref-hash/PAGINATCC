// DashboardCEO.jsx (CORREGIDO CON ==)

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2 } from "lucide-react";
import axios from "axios";

export default function DashboardCEO() {
  const navigate = useNavigate();
  const [hospitales, setHospitales] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [nuevoHospital, setNuevoHospital] = useState({ nombre: "", direccion: "" });
  const [nuevoAdmin, setNuevoAdmin] = useState({ usuario: "", password: "", hospitalld: "" });
  const [ceo, setCeo] = useState(null);
  
  const api = axios.create({
    baseURL: "http://localhost:8080",
    withCredentials: true,
  });

  // Verificar CEO logueado
  useEffect(() => {
    const ceoData = JSON.parse(localStorage.getItem("usuarioCEO"));
    if (!ceoData) navigate("/login-ceo");
    else setCeo(ceoData);
  }, [navigate]);

  // 1. Cargar hospitales al iniciar
  useEffect(() => {
    fetchHospitales();
  }, []);

  // 2. Cargar admins SÓLO DESPUÉS de que los hospitales hayan cargado
  useEffect(() => {
    // Solo busca admins si ya tenemos la lista de hospitales
    if (hospitales.length > 0) {
      fetchAdmins();
    }
  }, [hospitales]); // <-- Este useEffect "depende" de los hospitales

  const fetchHospitales = async () => {
    try {
      const res = await api.get("/hospitals");
      setHospitales(res.data || []);
    } catch (err) {
      console.error(err);
      alert("Error cargando hospitales");
    }
  };

  const fetchAdmins = async () => {
    try {
      const res = await api.get("/users?role=ADMIN");
      const adminsConHospital = (res.data || []).map(admin => {
        
        // ===================================
        //  ¡¡AQUÍ ESTÁ EL CAMBIO!! (=== por ==)
        // ===================================
        const hospital = hospitales.find(h => h.id == admin.hospitalld);
        
        return {
          ...admin,
          hospitalNombre: hospital ? hospital.nombre : "Sin hospital"
        };
      });
      setAdmins(adminsConHospital);
    } catch (err) {
      console.error(err);
      alert("Error cargando administradores");
    }
  };

  const crearHospital = async () => {
    // ... (sin cambios)
    if (!nuevoHospital.nombre.trim()) return alert("Debes ingresar el nombre del hospital");
    try {
      const res = await api.post("/hospitals", {
        nombre: nuevoHospital.nombre,
        direccion: nuevoHospital.direccion,
      });
      setHospitales([...hospitales, res.data]);
      setNuevoHospital({ nombre: "", direccion: "" });
    } catch (err) {
      console.error(err);
      alert("No se pudo crear el hospital");
    }
  };

  const crearAdmin = async () => {
    // ... (sin cambios)
    if (!nuevoAdmin.usuario || !nuevoAdmin.password || !nuevoAdmin.hospitalld)
      return alert("Completa usuario, contraseña y hospital");
    if (nuevoAdmin.password.length < 6)
      return alert("La contraseña debe tener al menos 6 caracteres");
    try {
      const res = await api.post("/users", {
        usuario: nuevoAdmin.usuario,
        password: nuevoAdmin.password,
        hospitalld: parseInt(nuevoAdmin.hospitalld, 10), // Mantenemos el parseInt aquí
        role: "ADMIN",
      });
      
      // ===================================
      //  ¡¡AQUÍ ESTÁ EL CAMBIO!! (=== por ==)
      // ===================================
      const hospitalAsignado = hospitales.find(h => h.id == nuevoAdmin.hospitalld);
      
      const adminConHospital = {
        ...res.data,
        hospitalNombre: hospitalAsignado ? hospitalAsignado.nombre : "Sin hospital",
      };
      
      setAdmins([...admins, adminConHospital]);
      setNuevoAdmin({ usuario: "", password: "", hospitalld: "" });
    } catch (err) {
      console.error(err);
      alert("No se pudo crear el administrador: " + (err.response?.data?.message || err.message));
    }
  };

  const eliminarHospital = async (id) => {
    // ... (sin cambios)
    if (!window.confirm("¿Eliminar este hospital y todo lo vinculado?")) return;
    try {
      await api.delete(`/hospitals/${id}`);
      setHospitales(hospitales.filter(h => h.id !== id));
      setAdmins(admins.filter(a => a.hospitalld !== id)); 
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el hospital");
    }
  };

  const eliminarAdmin = async (id) => {
    // ... (sin cambios)
    if (!window.confirm("¿Eliminar este administrador?")) return;
    try {
      await api.delete(`/users/${id}`);
      setAdmins(admins.filter(a => a.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el administrador");
    }
  };

  // ===================================
  //  HTML / RENDER (Sin cambios)
  // ===================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        {/* ... (sin cambios) ... */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/roles")}
            className="flex items-center gap-2 px-3 py-2 bg-white shadow rounded-full hover:bg-gray-100 transition"
          >
            <ArrowLeft className="text-blue-700" size={22} />
          </button>
          <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Panel CEO</h1>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => navigate("/simulador-tcc")}
            className="px-4 py-2 bg-yellow-500 text-white rounded-lg shadow hover:bg-yellow-600 transition"
          >
            Simulador TCC
          </button>
          <button
            onClick={() => navigate("/estadisticas")}
            className="px-4 py-2 bg-indigo-500 text-white rounded-lg shadow hover:bg-indigo-600 transition"
          >
            Estadísticas
          </button>
          <button
            onClick={() => {
              localStorage.removeItem("usuarioCEO");
              navigate("/roles");
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg shadow hover:bg-blue-600 transition"
          >
            Cerrar sesión
          </button>
        </div>
      </div>

      {/* Crear Hospital y Admin */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Crear Hospital */}
        <div className="bg-white rounded-xl shadow p-6">
          {/* ... (sin cambios) ... */}
          <h2 className="text-lg font-semibold text-blue-700 mb-4">Crear Hospital</h2>
          <input
            type="text"
            placeholder="Nombre del hospital"
            value={nuevoHospital.nombre}
            onChange={(e) => setNuevoHospital({ ...nuevoHospital, nombre: e.target.value })}
            className="w-full mb-3 p-2 border rounded-lg"
          />
          <input
            type="text"
            placeholder="Dirección (opcional)"
            value={nuevoHospital.direccion}
            onChange={(e) => setNuevoHospital({ ...nuevoHospital, direccion: e.target.value })}
            className="w-full mb-3 p-2 border rounded-lg"
          />
          <button
            onClick={crearHospital}
            className="w-full py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
          >
            Crear
          </button>
        </div>
        {/* Crear Admin */}
        <div className="bg-white rounded-xl shadow p-6">
          {/* ... (sin cambios) ... */}
          <h2 className="text-lg font-semibold text-blue-700 mb-4">Crear Administrador</h2>
          <input
            type="text"
            placeholder="Usuario"
            value={nuevoAdmin.usuario}
            onChange={(e) => setNuevoAdmin({ ...nuevoAdmin, usuario: e.target.value })}
            className="w-full mb-3 p-2 border rounded-lg"
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={nuevoAdmin.password}
            onChange={(e) => setNuevoAdmin({ ...nuevoAdmin, password: e.target.value })}
            className="w-full mb-3 p-2 border rounded-lg"
          />
          <select
            value={nuevoAdmin.hospitalld}
            onChange={(e) => setNuevoAdmin({ ...nuevoAdmin, hospitalld: e.target.value })}
            className="w-full mb-3 p-2 border rounded-lg"
          >
            <option value="">Selecciona hospital</option>
            {hospitales.map(h => (
              <option key={h.id} value={h.id}>
                {h.nombre} {h.direccion && `(${h.direccion})`}
              </option>
            ))}
          </select>
          <button
            onClick={crearAdmin}
            className="w-full py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
          >
            Crear
          </button>
        </div>
        {/* Invitaciones */}
        <div className="bg-white rounded-xl shadow p-6">
          {/* ... (sin cambios) ... */}
          <h2 className="text-lg font-semibold text-blue-700 mb-4">Invitaciones</h2>
          <p className="text-gray-500 text-sm mt-3">Funcionalidad pendiente.</p>
        </div>
      </div>

      {/* Listados */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hospitales */}
        <div className="bg-white rounded-xl shadow p-6">
          {/* ... (sin cambios) ... */}
          <h2 className="text-lg font-semibold text-blue-700 mb-4">Hospitales</h2>
          {hospitales.length === 0 ? (
            <p className="text-gray-500">Sin registros.</p>
          ) : (
            <ul className="space-y-2">
              {hospitales.map(h => (
                <li key={h.id} className="flex justify-between items-center border p-2 rounded-lg">
                  <span>{h.nombre} {h.direccion && `(${h.direccion})`}</span>
                  <button
                    onClick={() => eliminarHospital(h.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={18} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        {/* Administradores */}
        <div className="bg-white rounded-xl shadow p-6">
          {/* ... (sin cambios) ... */}
          <h2 className="text-lg font-semibold text-blue-700 mb-4">Administradores</h2>
          {admins.length === 0 ? (
            <p className="text-gray-500">Sin registros.</p>
          ) : (
            <ul className="space-y-2">
              {admins.map(a => (
                <li key={a.id} className="flex justify-between items-center border p-2 rounded-lg">
                  <span>{a.usuario} – {a.hospitalNombre}</span>
                  <button
                    onClick={() => eliminarAdmin(a.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={18} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}