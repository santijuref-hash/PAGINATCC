// src/pages/Home.jsx
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
export default function Home() {
 return (
 <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-brfrom-blue-50 to-blue-100 text-gray-800">
 {/* Botón atrás */}
 <a
 href="https://tccweb.my.canva.site/"
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all"
 >
 <ArrowLeft size={30} />
 </a>
 {/* Contenido central */}
 <motion.div
 initial={{ opacity: 0, y: -20 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ duration: 0.6 }}
 className="text-center px-4"
 >
 <h1 className="text-6xl md:text-7xl font-bold text-blue-900 drop-shadow-sm">
 Bienvenido al sistema
 </h1>
 <p className="mt-6 text-2xl md:text-3xl text-gray-700">
 Seleccione su rol para continuar
 </p>
 {/* Botón */}
 <motion.div
 initial={{ opacity: 0, y: 20 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ delay: 0.3, duration: 0.6 }}
 className="mt-12"
 >
 <Link
 to="/roles"
 className="px-10 py-5 bg-blue-600 hover:bg-blue-700 text-white text-xl rounded 2xl shadow-lg transition-all"
 >
 Ingresar
 </Link>
 </motion.div>
 </motion.div>
 </div>
 );
}
