// src/pages/Roles.jsx
import { ArrowLeft, UserCog, Stethoscope, User, Briefcase } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
export default function Roles() {
 const roles = [
 {
 nombre: "CEO",
 icon: Briefcase,
 color: "bg-blue-100",
 iconColor: "text-blue-700",
 ruta: "/login-ceo"
 },
 {
 nombre: "Administrador",
 icon: UserCog,
 color: "bg-green-100",
 iconColor: "text-green-700",
 ruta: "/login-admin"
 },
 {
 nombre: "Enfermera",
 icon: Stethoscope,
 color: "bg-pink-100",
 iconColor: "text-pink-700",
 ruta: "/login-enfermera"
 },
 {
 nombre: "Paciente",
 icon: User,
 color: "bg-purple-100",
 iconColor: "text-purple-700",
 ruta: "/login-paciente" // apunta al login del paciente ✅
 },
 ];
 return (
 <div className="relative min-h-screen flex flex-col items-center justify-center bggradient-to-br from-blue-50 to-blue-100 text-gray-800">
 {/* Botón atrás */}
 <Link
 to="/"
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40
hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all"
 >
 <ArrowLeft size={30} />
 </Link>
 {/* Título */}
 <motion.h2
 initial={{ opacity: 0, y: -20 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ duration: 0.6 }}
 className="text-4xl md:text-5xl font-bold text-blue-900 mb-16"
 >
 Seleccione su Rol
 </motion.h2>
 {/* Grid de roles */}
 <div className="grid grid-cols-1 md:grid-cols-4 gap-10 px-6 w-full max-w-6xl">
 {roles.map((rol, index) => (
 <motion.div
 key={rol.nombre}
 initial={{ opacity: 0, y: 40 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ delay: index * 0.2, duration: 0.5 }}
 whileHover={{ scale: 1.05, y: -5 }}
 >
 <Link
 to={rol.ruta}
 className={`flex flex-col items-center justify-center p-12 rounded-2xl shadow-md
hover:shadow-xl transition-all ${rol.color}`}
 >
 <rol.icon size={70} className={`mb-4 ${rol.iconColor}`} />
 <span className="text-2xl font-semibold text-gray-800">{rol.nombre}</span>
 </Link>
 </motion.div>
 ))}
 </div>
 </div>
 );
}
