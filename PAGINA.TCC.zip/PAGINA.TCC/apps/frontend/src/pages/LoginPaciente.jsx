import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
export default function LoginPaciente() {
 const [dni, setDni] = useState("");
 const [nombre, setNombre] = useState("");
 const [error, setError] = useState("");
 const navigate = useNavigate();
 const handleLogin = async (e) => {
 e.preventDefault();
 setError("");
 try {
 // Llamamos al endpoint de pacientes
 const res = await fetch(
 `http://localhost:8080/pacientes?dni=${dni}&nombre=${encodeURIComponent(nombre)}`
 );
 if (!res.ok) throw new Error("Error al buscar paciente");
 const data = await res.json();
 if (!data || data.length === 0) {
 setError("Paciente no encontrado");
 return;
 }
 const paciente = data[0];
 // Obtener información del TCC asignado
 let tccNombre = "Sin asignar";
 if (paciente.tccId) {
   const resTcc = await fetch(`http://localhost:8080/devices/${paciente.tccId}`);
 if (resTcc.ok) {
 const tccData = await resTcc.json();
 tccNombre = tccData.nombre || "Sin asignar";
 }
 }
 // Obtener información de la patología asignada
 let patologiaNombre = "No asignada";
 if (paciente.patologiaId) {
 const resPat = await fetch(`http://localhost:8080/patologias/${paciente.patologiaId}`);
 if (resPat.ok) {
 const patData = await resPat.json();
 patologiaNombre = patData.name || "No asignada";
 }
 }
 // Obtener información del hospital
 let hospitalNombre = "Sin asignar";
 if (paciente.hospitalId) {
 const resHosp = await fetch(`http://localhost:8080/hospitales/${paciente.hospitalld}`);
 if (resHosp.ok) {
 const hospData = await resHosp.json();
 hospitalNombre = hospData.nombre || paciente.hospitalld;
 }
 }
 // Guardar paciente con nombres completos
 const pacienteLogueado = {
 ...paciente,
 tccNombre,
 patologiaNombre,
 hospitalNombre,
 };
 localStorage.setItem("usuarioPaciente", JSON.stringify(pacienteLogueado));
 navigate("/dashboard-paciente");
 } catch (err) {
 console.error(err);
 setError(err.message || "Error al iniciar sesión");
 }
 };
 return (
 <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-brfrom-purple-50 to-purple-100">
 <Link to="/roles"
 className="absolute top-6 left-6 text-gray-700 hover:text-gray-900 bg-white/40hover:bg-white/70 backdrop-blur-md p-3 rounded-full shadow-lg transition-all">
<ArrowLeft size={28} />
 </Link>
 <motion.div
 initial={{ opacity: 0, scale: 0.9 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ duration: 0.5 }}
 className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md"
 >
 <h2 className="text-3xl font-bold text-center text-purple-700 mb-6">
 Login Paciente
 </h2>
 <form onSubmit={handleLogin} className="space-y-5">
 <div>
 <label className="block text-gray-700 font-medium">
 Nombre completo
 </label>
 <input
 type="text"
 value={nombre}
 onChange={(e) => setNombre(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2focus:ring-purple-400 outline-none"
 placeholder="Ingresa tu nombre"
 required
 />
 </div>
 <div>
 <label className="block text-gray-700 font-medium">DNI</label>
 <input
 type="text"
 value={dni}
 onChange={(e) => setDni(e.target.value)}
 className="w-full mt-2 p-3 border border-gray-300 rounded-xl focus:ring-2focus:ring-purple-400 outline-none"
 placeholder="Ingresa tu DNI"
 required
 />
 </div>
 {error && <p className="text-red-500 text-sm text-center">{error}</p>}
 <motion.button
 whileHover={{ scale: 1.05 }}
 whileTap={{ scale: 0.95 }}
 type="submit"
 className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-xlfont-semibold transition-all"
 >
 Ingresar
 </motion.button>
 </form>
 </motion.div>
 </div>
 );
}
