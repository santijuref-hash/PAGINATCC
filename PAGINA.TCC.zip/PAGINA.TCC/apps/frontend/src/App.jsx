import { Routes, Route } from 'react-router-dom';

// Inicio y Roles
import Home from './pages/Home'; // <-- TE FALTA ESTA
import Roles from './pages/Roles'; // <-- TE FALTA ESTA

// CEO
import LoginCEO from './pages/LoginCEO'; // <-- TE FALTA ESTA
import DashboardCEO from './pages/DashboardCEO'; // <-- TE FALTA ESTA
import EstadisticasCEO from './pages/EstadisticasCEO'; // <-- TE FALTA ESTA

// Admin
import LoginAdmin from './pages/LoginAdmin'; // <-- TE FALTA ESTA
import DashboardAdmin from './pages/DashboardAdmin'; // <-- TE FALTA ESTA

// Enfermera
import LoginEnfermera from './pages/LoginEnfermera'; // <-- TE FALTA ESTA
import DashboardEnfermera from './pages/DashboardEnfermera'; // <-- TE FALTA ESTA
import RegistrosEnfermera from './pages/RegistrosEnfermera'; // <-- TE FALTA ESTA
import AlertasEnfermera from './pages/AlertasEnfermera'; // <-- TE FALTA ESTA

// Paciente (Estos ya los tenías)
import LoginPaciente from "./pages/LoginPaciente";
import DashboardPaciente from "./pages/DashboardPaciente";

// Simulador (Este ya lo tenías)
import SimuladorTCC from "./pages/SimuladorTCC";

// ... aquí sigue el resto de tu código (function App() ...)
function App() {
 return (
 <Routes>
 {/* Inicio */}
 <Route path="/" element={<Home />} />
 {/* Selección de roles */}
 <Route path="/roles" element={<Roles />} />
 {/* CEO */}
 <Route path="/login-ceo" element={<LoginCEO />} />
 <Route path="/dashboard-ceo" element={<DashboardCEO />} />
 <Route path="/estadisticas" element={<EstadisticasCEO />} />
 {/* Admin */}
 <Route path="/login-admin" element={<LoginAdmin />} />
 <Route path="/dashboard-admin" element={<DashboardAdmin />} />
 {/* Enfermera */}
 <Route path="/login-enfermera" element={<LoginEnfermera />} />
 <Route path="/dashboard-enfermera" element={<DashboardEnfermera />} />
 <Route path="/registros-enfermera" element={<RegistrosEnfermera />} />
 <Route path="/alertas-enfermera" element={<AlertasEnfermera />} />
 {/* Paciente */}
 <Route path="/login-paciente" element={<LoginPaciente />} />
 <Route path="/dashboard-paciente" element={<DashboardPaciente />} />
 {/* Simulador TCC */}
 <Route path="/simulador-tcc" element={<SimuladorTCC />} />
 </Routes>
 );
}
export default App;