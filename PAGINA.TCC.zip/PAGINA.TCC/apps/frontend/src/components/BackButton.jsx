import React from "react";
import { Link } from "react-router-dom";
/** Botón back grande, translúcido, arriba a la izquierda.
 * - href externo: usar prop externalHref
 * - ruta interna: usar prop to
 */
export default function BackButton({ to, externalHref, label = "Volver" }) {
 const classes =
 "group fixed left-4 top-4 z-50 flex h-11 w-11 items-center justify-center rounded-full \
 bg-white/30 shadow-lg shadow-black/10 ring-1 ring-white/40 backdrop-blur \
 transition hover:bg-white/50 focus:outline-none focus-visible:ring-2 focus-visible:ringwhite";
 // Si es externo (al sitio de Canva)
 if (externalHref) {
 return (
 <a href={externalHref} className={classes} aria-label={label}>
 <ArrowIcon />
 </a>
 );
 }
 // Si es navegación interna
 return (
 <Link to={to || "/"} className={classes} aria-label={label}>
 <ArrowIcon />
 </Link>
 );
}
function ArrowIcon() {
 return (
 <svg
 viewBox="0 0 24 24"
 className="h-6 w-6 text-white/90 transition group-hover:translate-x-[-1px]"
 fill="none"
  stroke="currentColor"
 strokeWidth="2.2"
 strokeLinecap="round"
 strokeLinejoin="round"
 aria-hidden="true"
 >
 <path d="M15 18l-6-6 6-6" />
 </svg>
 );
}