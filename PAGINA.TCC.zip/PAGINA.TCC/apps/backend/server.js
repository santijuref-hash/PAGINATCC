// server.js
const express = require("express");
const cors = require("cors");
const { Op } = require("sequelize");
const {
 sequelize,
 User,
 Hospital,
 Nurse,
 Patient,
 Pathology,
 Device,
 Alert,
} = require("./models");
const app = express();
app.use(express.json());
app.use(cors({ origin: "http://localhost:5173", credentials: true }));
// ------------------ LOGIN ------------------
app.post("/users/login", async (req, res) => {
 try {
 const { usuario, password } = req.body;
 const user = await User.findOne({ where: { usuario } });
 if (!user) return res.status(401).json({ message: "Usuario no encontrado" });
 if (user.password !== password)
 return res.status(401).json({ message: "Contraseña incorrecta" });
 const hospital = user.hospitalld ? await Hospital.findByPk(user.hospitalld) : null;
 res.json({
 id: user.id,
 usuario: user.usuario,
 role: user.role ? user.role.toUpperCase() : null,
 hospitalld: user.hospitalld,
 hospitalNombre: hospital ? hospital.nombre : null,
 });
 } catch (error) {
 console.error("Error login:", error);
 res.status(500).json({ message: "Error interno del servidor" });
 }
});
// ------------------ USERS ------------------
app.get("/users", async (req, res) => {
 try {
 const { role } = req.query;
 const users = await User.findAll({ where: role ? { role } : {} });
 res.json(users);
 } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
app.post("/users", async (req, res) => {
 try {
    console.log("DATOS RECIBIDOS PARA CREAR USER:", req.body);
 const { usuario, password, role, hospitalld } = req.body;
 const newUser = await User.create({ usuario, password, role, hospitalld });
 res.json(newUser);
  } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
app.delete("/users/:id", async (req, res) => {
 try {
 const { id } = req.params;
 const deleted = await User.destroy({ where: { id } });
 if (!deleted) return res.status(404).send("Usuario no encontrado");
 res.sendStatus(200);
 } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
// ------------------ HOSPITALES ------------------
app.get("/hospitals", async (req, res) => {
 try {
 const hospitals = await Hospital.findAll();
 res.json(hospitals);
 } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
app.post("/hospitals", async (req, res) => {
 try {
 const { nombre, direccion } = req.body;
 const newHospital = await Hospital.create({ nombre, direccion });
 res.json(newHospital);
 } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
app.delete("/hospitals/:id", async (req, res) => {
 try {
 const { id } = req.params;
 await User.destroy({ where: { hospitalld: id } });
 const deleted = await Hospital.destroy({ where: { id } });
 if (!deleted) return res.status(404).send("Hospital no encontrado");
 res.sendStatus(200);
 } catch (error) {
 console.error(error);
 res.status(500).json({ error: error.message });
 }
});
// ------------------ PACIENTES ------------------
app.get("/pacientes", async (req, res) => {
 const { hospitalld, dni, nombre } = req.query;
 try {
 const whereClause = {};
 if (hospitalld) whereClause.hospitalld = hospitalld;
 if (dni) whereClause.dni = dni;
 if (nombre) whereClause.nombre = { [Op.like]: `%${nombre}%` };
 const pacientes = await Patient.findAll({ where: whereClause });
 res.json(pacientes);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener pacientes" });
 }
});
app.post("/pacientes", async (req, res) => {

 // [CITE: 1093]
 const { nombre, dni, edad, hospitalld, patologiald, tccld } = req.body;

 // [CITE: 1094]
 if (!nombre || !dni || !hospitalld) {
 return res.status(400).json({ message: "Faltan datos" });
 }
 // [CITE: 1095]
 try {
 // 1. Buscar los NOMBRES usando los IDs
 const patologiaObj = patologiald ? await Pathology.findByPk(patologiald) : null;
 const tccObj = tccld ? await Device.findByPk(tccld) : null; // <-- Obtenemos el TCC
 // 2. Obtener los strings (texto)
 const nombrePatologia = patologiaObj ? patologiaObj.name : null;
 const nombreTcc = tccObj ? tccObj.nombre : null;
 // 3. Crear el paciente
 const newPatient = await Patient.create({
 nombre,
 dni,
 edad: edad || null,
 hospitalld: hospitalld, // [CITE: de tu error anterior]
 patologia: nombrePatologia, // [CITE: 500]
 tcc: nombreTcc, // [CITE: 500]
 });
 // --- INICIO DE LA CORRECCIÓN (Problema 2) ---
 // 4. Asignar el ID del nuevo paciente al TCC
  if (tccObj) {
 tccObj.patientId = newPatient.id; // [CITE: 399]
 await tccObj.save();
 }
 // --- FIN DE LA CORRECCIÓN ---
 res.status(201).json(newPatient); // [CITE: 1104]

 } catch (err) {
 // (Resto del catch... [CITE: 1105-1109])
 if (err.name === "SequelizeUniqueConstraintError") {
 return res.status(400).json({ message: "Ya existe un paciente con ese DNI" });
 }
 console.error("Error crear paciente:", err);
 res.status(500).json({ message: "Error al crear paciente" });
 }
});
app.delete("/pacientes/:id", async (req, res) => {
 const { id } = req.params;
 try {
 const deleted = await Patient.destroy({ where: { id } });
 if (!deleted) return res.status(404).json({ message: "Paciente no encontrado" });
 res.json({ message: "Paciente eliminado" });
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al eliminar paciente" });
 }
});
// ------------------ PATOLOGÍAS ------------------
app.get("/patologias", async (req, res) => {
 const { hospitalld } = req.query;
 try {
 const whereClause = hospitalld ? { hospitalld } : {};
 const patologias = await Pathology.findAll({ where: whereClause });
 res.json(patologias);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener patologías" });
 }
});
app.post("/patologias", async (req, res) => {
 const { name, level, hospitalld } = req.body;
 if (!name || !level || !hospitalld)
 return res.status(400).json({ message: "Faltan datos" });
 try {
 const patologia = await Pathology.create({ name, level, hospitalld });
 res.status(201).json(patologia);
 } catch (err) {
 console.error(err)
  res.status(500).json({ message: "Error al crear patología" });
 }
});
app.delete("/patologias/:id", async (req, res) => {
 const { id } = req.params;
 try {
 const deleted = await Pathology.destroy({ where: { id } });
 if (!deleted) return res.status(404).json({ message: "Patología no encontrada" });
 res.json({ message: "Patología eliminada" });
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al eliminar patología" });
 }
});
// ------------------ DISPOSITIVOS ------------------
app.get("/devices/hospital/:hospitalld", async (req, res) => {
 try {
 const { hospitalld } = req.params;
 const devices = await Device.findAll({ where: { hospitalld } });
 res.json(Array.isArray(devices) ? devices : []);
 } catch (err) {
 console.error("Error al obtener dispositivos:", err);
 res.status(500).json({ message: "Error al obtener dispositivos" });
 }
});
app.post("/devices/simulated", async (req, res) => {
 const { hospitalld, nombre, tipo } = req.body;
 if (!hospitalld || !nombre)
 return res.status(400).json({ message: "Faltan datos" });
 try {
 const device = await Device.create({
 hospitalld,
 nombre,
 tipo: tipo || "simulado",
 simulacion: true,
 activo: false,
 });
 res.status(201).json(device);
 } catch (err) {
 console.error("Error al crear dispositivo:", err);
 res.status(500).json({ message: "Error al crear dispositivo" });
 }
});
// NUEVA RUTA PARA REGISTRAR UN TCC REAL (llamada desde SimuladorTCC.jsx)
app.post("/devices/connect", async (req, res) => {
  // Recibimos la MAC, nombre y hospital
  const { macAddress, nombre, hospitalld } = req.body;
  if (!macAddress || !nombre || !hospitalld) {
    return res.status(400).json({ message: "Faltan datos (MAC, nombre, hospital)" });
  }
  try {
    const device = await Device.create({
      macAddress: macAddress, // Guardamos la MAC
      nombre,
      hospitalld,
      tipo: "real",
      simulacion: false,
      activo: false,
    });
    res.status(201).json(device);
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError') {
       return res.status(400).json({ message: "Ese ID de dispositivo (MAC) ya está registrado." });
    }
    console.error("Error al registrar TCC real:", err);
    res.status(500).json({ message: "Error al registrar dispositivo" });
  }
});
app.put("/devices/:id/encendido", async (req, res) => {
 try {
 const { id } = req.params;
 const { encendido } = req.body;
 const device = await Device.findByPk(id)
  if (!device) return res.status(404).json({ message: "Dispositivo no encontrado" });
 device.activo = Boolean(encendido);
 await device.save();
 res.json({
 id: device.id,
 nombre: device.nombre,
 activo: device.activo,
 hospitalld: device.hospitalld,
 tipo: device.tipo,
 simulacion: device.simulacion,
 });
 } catch (err) {
 console.error("Error al actualizar encendido:", err);
 res.status(500).json({ message: "Error al actualizar encendido" });
 }
});
app.put("/devices/:id/nombre", async (req, res) => {
 try {
 const { id } = req.params;
 const { nombre } = req.body;
 const device = await Device.findByPk(id);
 if (!device) return res.status(404).json({ message: "Dispositivo no encontrado" });
 if (!nombre) return res.status(400).json({ message: "Falta nombre" });
 device.nombre = nombre;
 await device.save();
 res.json(device);
 } catch (err) {
 console.error("Error al renombrar dispositivo:", err);
 res.status(500).json({ message: "Error al renombrar dispositivo" });
 }
});
app.delete("/devices/:id", async (req, res) => {
 try {
 const { id } = req.params;
 const deleted = await Device.destroy({ where: { id } });
 if (!deleted) return res.status(404).json({ message: "Dispositivo no encontrado" });
 res.sendStatus(200);
 } catch (err) {
 console.error("Error al borrar dispositivo:", err);
 res.status(500).json({ message: "Error al borrar dispositivo" });
 }
});
// ------------------ ALERTAS ------------------
app.get("/alerts/hospital/:hospitalld", async (req, res) => {
  try {
    const { hospitalld } = req.params;

    // 1. Encontrar los dispositivos de ese hospital
    const devices = await Device.findAll({ 
      where: { hospitalld },
      attributes: ['id'] // Solo necesitamos sus IDs
    });
    const deviceIds = devices.map((d) => d.id);

    // 2. Encontrar las alertas de esos dispositivos
    const alerts = await Alert.findAll({ 
      where: { deviceId: deviceIds },
      
      // --- ¡¡ESTA ES LA MAGIA!! ---
      // Incluimos el modelo "Patient" usando la asociación "patient"
      // que definimos en models/index.js
      include: {
        model: Patient,
        as: 'patient', // El alias de la asociación
        attributes: ['nombre'] // Solo traemos el nombre del paciente
      },
      // -----------------------------
      
      order: [['timestamp', 'DESC']] // Opcional: muestra las más nuevas primero
    });
 res.json(alerts);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener alertas" });
 }
});
// En server.js

// En server.js

// RUTA DE ALERTAS CORREGIDA (AHORA ACEPTA SIMULADAS Y REALES)
app.post("/alerts", async (req, res) => {
  
  // Leemos todos los posibles datos
  const { macAddress, deviceId, patientId, urgency, need } = req.body;

  // --- RUTA 1: ALERTA DE TCC REAL (viene con macAddress) ---
  if (macAddress) {
    if (!urgency || !need) {
      console.log("Error 400 (Real): Faltan datos", req.body);
      return res.status(400).json({ message: "Faltan datos: urgency, need" });
    }
    try {
      // 1. Buscar el dispositivo por su MAC
      const device = await Device.findOne({ where: { macAddress: macAddress } });
      if (!device) {
        console.log(`Error 404 (Real): MAC ${macAddress} no encontrada.`);
        return res.status(404).json({ message: "Dispositivo (MAC) no registrado" });
      }
      if (!device.patientId) {
        console.log(`Error 400 (Real): Dispositivo ${device.id} no asignado.`);
        return res.status(400).json({ message: "Dispositivo no asignado a un paciente" });
      }
      
      // 2. Marcar como activo y crear alerta
      device.activo = true;
      await device.save();
      const alert = await Alert.create({
        deviceId: device.id, // Usamos el ID numérico
        urgency,
        need,
        patientId: device.patientId, // Obtenido de la BBDD
        timestamp: new Date(),
      });
      return res.status(201).json(alert);

    } catch (err) {
      console.error("Error procesando alerta REAL:", err);
      return res.status(500).json({ message: "Error al enviar alerta real" });
    }
  }

  // --- RUTA 2: ALERTA DE TCC SIMULADO (viene con deviceId) ---
  if (deviceId) {
    if (!patientId || !urgency || !need) {
      console.log("Error 400 (Simulado): Faltan datos", req.body);
      return res.status(400).json({ message: "Faltan datos: deviceId, patientId, urgency, need" });
    }
    try {
      // 1. (Opcional) Marcar el simulador como activo
      const device = await Device.findByPk(deviceId);
      if (device) {
        device.activo = true;
        await device.save();
      }

      // 2. Crear la alerta (como hacíamos antes)
      const alert = await Alert.create({
        deviceId,
        urgency,
        need,
        patientId,
        timestamp: new Date(),
      });
      return res.status(201).json(alert);
    
    } catch (err) {
      console.error("Error procesando alerta SIMULADA:", err);
      return res.status(500).json({ message: "Error al enviar alerta simulada" });
    }
  }

  // --- Si no envía ni macAddress ni deviceId ---
  console.log("Error 400 (General): No vino ni macAddress ni deviceId", req.body);
  return res.status(400).json({ message: "Faltan datos (se requiere macAddress o deviceId)" });
});

// Ruta para agregar/actualizar una nota en una alerta
app.put("/alerts/:id/nota", async (req, res) => {
  try {
    const { id } = req.params;
    const { nota } = req.body;

    const alert = await Alert.findByPk(id);
    if (!alert) {
      return res.status(404).json({ message: "Alerta no encontrada" });
    }

    alert.nota = nota || null; // Asigna la nota (o null si está vacía)
    await alert.save();

    res.json(alert); // Devuelve la alerta actualizada
  } catch (err) {
    console.error("Error al guardar nota:", err);
    res.status(500).json({ message: "Error al guardar nota" });
  }
});
// En server.js

// Ruta para borrar una alerta
app.delete("/alerts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Alert.destroy({ where: { id } });

    if (!deleted) {
      return res.status(404).json({ message: "Alerta no encontrada" });
    }

    res.status(200).json({ message: "Alerta eliminada" });
  } catch (err) {
    console.error("Error al eliminar alerta:", err);
    res.status(500).json({ message: "Error al eliminar alerta" });
  }
});
// ------------------ INICIAR SERVIDOR ------------------
const PORT = 8080;
(async () => {
 try {
await sequelize.sync({ alter: true }); // ¡Aplica cambios!
console.log("Base de datos sincronizada");
 app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));
 } catch (error) {
 console.error("Error al conectar con la base de datos:", error);
 }
})();