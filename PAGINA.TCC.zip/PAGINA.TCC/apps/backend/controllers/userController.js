const { User, Hospital } = require('../models');
const bcrypt = require('bcryptjs'); // para encriptar contraseñas
module.exports = {
 // Obtener todos los usuarios con su hospital
 getAllUsers: async (req, res) => {
 try {
 const users = await User.findAll({
 include: {
 model: Hospital,
 as: 'hospital' // coincide con el alias del index
 }
 });
 res.json(users);
 } catch (error) {
 console.error('Error al obtener usuarios:', error);
 res.status(500).json({ message: 'Error al obtener usuarios', error: error.message });
 }
 },
 // Obtener un usuario por ID
 getUserById: async (req, res) => {
 const { id } = req.params;
 try {
 const user = await User.findByPk(id, {
 include: {
 model: Hospital,
 as: 'hospital'
 }
 });
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 res.json(user);
 } catch (error) {
 console.error('Error al obtener usuario:', error);
 res.status(500).json({ message: 'Error al obtener usuario', error: error.message });
 }
 },
 // Crear un usuario
 createUser: async (req, res) => {
 const { usuario, password, role, hospitalld } = req.body;
 try {
 // Encriptamos la contraseña
 const hashedPassword = await bcrypt.hash(password, 10);
 const user = await User.create({
 usuario,
 password: hashedPassword,
 role,
 hospitalld
 });
 res.status(201).json(user);
 } catch (error) {
 console.error('No se pudo crear el usuario:', error);
 res.status(500).json({ message: 'No se pudo crear el usuario', error: error.message });
 }
 },
 // Actualizar un usuario
 updateUser: async (req, res) => {
 const { id } = req.params;
 const { usuario, password, role, hospitalld } = req.body;
 try {
 const user = await User.findByPk(id);
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 if (password) {
 user.password = await bcrypt.hash(password, 10);
 }
 if (usuario) user.usuario = usuario;
 if (role) user.role = role;
 if (hospitalld) user.hospitalld = hospitalld;
 await user.save();
 res.json(user);
 } catch (error) {
 console.error('Error al actualizar el usuario:', error);
 res.status(500).json({ message: 'Error al actualizar el usuario', error: error.message });
 }
 },
 // Eliminar un usuario
 deleteUser: async (req, res) => {
 const { id } = req.params;
 try {
 const user = await User.findByPk(id);
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 await user.destroy();
 res.json({ message: 'Usuario eliminado correctamente' });
 } catch (error) {
 console.error('Error al eliminar el usuario:', error);
 res.status(500).json({ message: 'Error al eliminar el usuario', error: error.message });
 }
 }
};