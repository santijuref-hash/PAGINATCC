// controllers/patientController.js
const loginPatient = async (req, res) => {
 const { dni, nombre } = req.body;
 if (!dni || !nombre) return res.status(400).json({ message: "Faltan datos" });
 const paciente = await Patient.findOne({ where: { dni, nombre } });
 if (!paciente) return res.status(404).json({ message: "Paciente no encontrado" });
 res.json(paciente);
}