const { Nurse, Hospital } = require("../models");
// Traer enfermeras de un hospital
exports.getNursesByHospital = async (req, res) => {
 try {
 const { hospitalId } = req.params;
 const nurses = await Nurse.findAll({
 where: { hospitalId },
 include: Hospital
 });
 res.json(nurses);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error cargando enfermeras" });
 }
};
// Crear enfermera
exports.createNurse = async (req, res) => {
 try {
 const { usuario, password, hospitalId } = req.body;
 if (!hospitalId) {
 return res.status(400).json({ message: "Falta hospitalId" });
 }
 const nurse = await Nurse.create({ usuario, password, hospitalId });
 res.json(nurse);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "No se pudo crear la enfermera" });
 }
};
// Eliminar enfermera
exports.deleteNurse = async (req, res) => {
 try {
 const { id } = req.params;
 await Nurse.destroy({ where: { id } });
 res.json({ message: "Enfermera eliminada" });
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error eliminando enfermera" });
 }
};
