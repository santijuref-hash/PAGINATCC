const { Alert, Patient, Nurse } = require("../models");
const Alerts = {
 async findAll(req, res) {
 try {
 const alerts = await Alert.findAll({
 include: [Patient, Nurse]
 });
 res.json(alerts);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error cargando alertas" });
 }
 },
 async create(req, res) {
 try {
 const { device_id, urgency, need, timestamp, patientId, nurseId } = req.body;
 if (!patientId || !nurseId) {
 return res.status(400).json({ message: "Falta patientId o nurseId" });
 }
 const alert = await Alert.create({ device_id, urgency, need, timestamp, patientId,
nurseId });
 res.status(201).json(alert);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "No se pudo crear la alerta" });
 }
 },
};
module.exports = Alerts;