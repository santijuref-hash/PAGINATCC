// controllers/hospitalController.js
const Hospital = require("../models/Hospital");
exports.getAll = async (req, res) => {
 try {
 const hospitals = await Hospital.findAll();
 res.json(hospitals);
 } catch (err) {
 console.error("Error GET /hospitals:", err);
 res.status(500).json({ error: err.message });
 }
};
exports.create = async (req, res) => {
 try {
 console.log("Payload recibido:", req.body);
 const { name, location } = req.body;
 if (!name) return res.status(400).json({ message: "El nombre es obligatorio" });
 const hospital = await Hospital.create({ name, location });
 res.json(hospital);
 } catch (err) {
 console.error("Error POST /hospitals:", err);
 res.status(500).json({ error: err.message });
 }
};
exports.delete = async (req, res) => {
 try {
 const { id } = req.params;
 await Hospital.destroy({ where: { id } });
 res.json({ message: "Hospital eliminado" });
 } catch (err) {
 console.error("Error DELETE /hospitals/:id:", err);
 res.status(500).json({ error: err.message });
 }
}