const pool = require("../config/db");
async function getEstadisticas(req, res) {
 const { hospitalld } = req.query;
 try {
 let query = `
 SELECT
 h.name AS hospital,
 COUNT(t.id) AS total_tcc,
 SUM(CASE WHEN t.conectado THEN 1 ELSE 0 END) AS activos,
 SUM(CASE WHEN t.finalizado THEN 1 ELSE 0 END) AS dados_alta
 FROM tcc t
 JOIN hospitals h ON t.hospital_id = h.id
 `;
 if (hospitalId) query += ` WHERE h.id = $1 GROUP BY h.name`;
 else query += ` GROUP BY h.name`;
 const params = hospitalId ? [hospitalld] : [];
 const result = await pool.query(query, params);
 res.json(result.rows);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener estadísticas" });
 }
}
module.exports = { getEstadisticas }