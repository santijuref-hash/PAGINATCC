const Device = require("../models/Device");
// Listar dispositivos simulados
exports.getSimulated = async (req, res) => {
 try {
 const devices = await Device.findAll({ where: { type: "SIMULATED" } });
 res.json(devices);
 } catch (err) {
 res.status(500).json({ error: err.message });
 }
};
// Crear dispositivo simulado
exports.createSimulated = async (req, res) => {
 try {
 const { hospital_id, name } = req.body;
 if (!hospital_id || !name) return res.status(400).json({ message: "Faltan datos" });
 const device = await Device.create({ name, hospital_id, type: "SIMULATED" });
 res.json(device);
 } catch (err) {
 res.status(500).json({ error: err.message });
 }
};
// Dispositivos por hospital
exports.getByHospital = async (req, res) => {
 try {
 const { id } = req.params;
 const devices = await Device.findAll({ where: { hospital_id: id } });
 res.json(devices);
 } catch (err) {
 res.status(500).json({ error: err.message });
 }
};