// apps/backend/controllers/authController.js
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Users = require("../models/User");
async function login(req, res, next) {
 try {
 const { email, password } = req.body;
 const u = await Users.findByEmail(email);
 if (!u) return res.status(401).json({ error: "Credenciales inválidas" });
 const ok = await bcrypt.compare(password, u.password_hash);
 if (!ok) return res.status(401).json({ error: "Credenciales inválidas" });
 const token = jwt.sign(
 { id: u.id, role: u.role, hospital_id: u.hospital_id, name: u.name },
 process.env.JWT_SECRET,
 { expiresIn: "7d" }
 );
 res.json({
 token,
 user: {
 id: u.id,
 role: u.role,
 hospital_id: u.hospital_id,
 name: u.name,
 email: u.email,
 },
 });
 } catch (e) {
 next(e);
 }
}
module.exports = { login }