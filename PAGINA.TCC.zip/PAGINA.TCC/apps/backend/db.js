// backend/db.js (MODIFICADO PARA RENDER)

const { Sequelize } = require("sequelize");

// Esta variable 'DATABASE_URL' nos la dará Render automáticamente
const connectionUrl = process.env.DATABASE_URL;

if (!connectionUrl) {
  throw new Error("DATABASE_URL no está definida. Asegúrate de configurar las variables de entorno.");
}

const sequelize = new Sequelize(connectionUrl, {
  dialect: 'postgres', // ¡Cambiado de 'sqlite' a 'postgres'!
  logging: false,
  // Configuración extra para Render (requiere SSL)
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false // Esto es necesario en Render
    }
  }
});

module.exports = sequelize;