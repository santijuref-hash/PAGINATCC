// apps/backend/utils/priority.js
/**
 * Calcula la prioridad final de una alerta
 * @param {"alta"|"media"|"baja"} urgencia
 * @param {number} pathologyLevel 1=leve, 2=media, 3=grave
 * @returns {number} prioridad (más alto = más urgente)
 */
function computePriority(urgencia, pathologyLevel = 3) {
 let base = 0;
 switch (urgencia) {
 case "alta":
 base = 3;
 break;
 case "media":
 base = 2;
 break;
 case "baja":
 base = 1;
 break;
 default:
 base = 1;
 }
 // Patología grave = mayor peso
 return base * pathologyLevel;
}
module.exports = { computePriority };