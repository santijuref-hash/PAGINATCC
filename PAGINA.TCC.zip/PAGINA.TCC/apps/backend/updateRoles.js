const { sequelize, User } = require('./db'); // Ajusta la ruta según tu proyecto
(async () => {
 try {
 await sequelize.sync(); // Asegura que la conexión esté lista
 // Actualizar todos los usuarios con role = "NURSE" a "ENFERMERA"
 const [updatedCount] = await User.update(
 { role: "ENFERMERA" },
 { where: { role: "NURSE" } }
 );
 console.log(`Se actualizaron ${updatedCount} usuarios de NURSE a ENFERMERA.`);
 process.exit(0);
 } catch (error) {
 console.error("Error actualizando roles:", error);
 process.exit(1);
 }
})();