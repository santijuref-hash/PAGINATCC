-- apps/backend/db/schema.sql
CREATE TABLE IF NOT EXISTS hospitals (
 id SERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 city TEXT
);
CREATE TABLE IF NOT EXISTS users (
 id SERIAL PRIMARY KEY,
 name TEXT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK (role IN ('CEO','ADMIN','ENFERMERA')),
 hospital_id INT REFERENCES hospitals(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS pathologies (
 id SERIAL PRIMARY KEY,
 hospital_id INT REFERENCES hospitals(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 level INT NOT NULL CHECK (level BETWEEN 1 AND 3)
);
CREATE TABLE IF NOT EXISTS patients (
 id SERIAL PRIMARY KEY,
 hospital_id INT REFERENCES hospitals(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 dni TEXT UNIQUE,
 age INT,
 pathology_name TEXT,
 bed TEXT
);
CREATE TABLE IF NOT EXISTS devices (
 id SERIAL PRIMARY KEY,
 hospital_id INT REFERENCES hospitals(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 secret TEXT UNIQUE NOT NULL,
 last_seen TIMESTAMP
);
CREATE TABLE IF NOT EXISTS alerts (
 id SERIAL PRIMARY KEY,
 hospital_id INT REFERENCES hospitals(id) ON DELETE CASCADE,
 device_id INT REFERENCES devices(id) ON DELETE SET NULL,
 tcc_id TEXT,
 necesidad TEXT,
 urgencia TEXT,
 time_text TEXT,
 patient_id INT REFERENCES patients(id) ON DELETE SET NULL,
 pathology_level INT,
 bed TEXT,
 priority INT,
 status TEXT DEFAULT 'nueva',
 note TEXT,
 created_at TIMESTAMP DEFAULT NOW()
);
