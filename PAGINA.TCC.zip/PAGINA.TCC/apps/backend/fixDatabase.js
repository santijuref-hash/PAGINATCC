const { sequelize, User, Hospital } = require("./models");
const { Op } = require("sequelize");

async function fixDatabase() {
  try {
    // Eliminar usuarios que no sean CEO ni ADMIN
    await User.destroy({
      where: {
        role: { [Op.notIn]: ["CEO", "ADMIN"] },
      },
    });

    // Opcional: eliminar hospitales sin usuarios
    const hospitales = await Hospital.findAll();
    for (const h of hospitales) {
      const count = await User.count({ where: { hospitalId: h.id } });
      if (count === 0) await h.destroy();
    }

    console.log("Base de datos limpiada correctamente");
    process.exit(0);
  } catch (err) {
    console.error("Error al limpiar la base de datos:", err);
  }
}

fixDatabase();
