const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");
class Nurse extends Model {}
Nurse.init({
 nombre: { type: DataTypes.STRING, allowNull: false },
 usuario: { type: DataTypes.STRING, allowNull: false, unique: true },
 password: { type: DataTypes.STRING, allowNull: false },
}, {
 sequelize,
 modelName: "Nurse",
 tableName: "nurses",
 timestamps: true,
});
module.exports = Nurse;