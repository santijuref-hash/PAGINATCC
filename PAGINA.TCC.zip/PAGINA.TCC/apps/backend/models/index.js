// models/index.js
const { Sequelize } = require("sequelize");
const sequelize = require("../db"); // tu instancia de Sequelize
// Importar modelos (definidos como clases ES6)
const Hospital = require("./Hospital");
const Nurse = require("./Nurse");
const User = require("./User");
const Patient = require("./Patient");
const Pathology = require("./Pathology");
const Device = require("./Device");
const Alert = require("./Alert");
// ============================
// Asociaciones
// ============================
// Hospital → Nurse
Hospital.hasMany(Nurse, { foreignKey: "hospitalld", as: "nurses" });
Nurse.belongsTo(Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Hospital → Patient
Hospital.hasMany(Patient, { foreignKey: "hospitalld", as: "patients" });
Patient.belongsTo(Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Nurse → Patient
Nurse.hasMany(Patient, { foreignKey: "nurseId", as: "patients" });
Patient.belongsTo(Nurse, { foreignKey: "nurseId", as: "nurse" });
// Hospital → User
Hospital.hasMany(User, { foreignKey: "hospitalld", as: "users" });
User.belongsTo(Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Hospital → Device
Hospital.hasMany(Device, { foreignKey: "hospitalld", as: "devices" });
Device.belongsTo(Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Device → Alert
Device.hasMany(Alert, { foreignKey: "deviceId", as: "alerts" });
Alert.belongsTo(Device, { foreignKey: "deviceId", as: "device" });
// Nurse → Alert
Nurse.hasMany(Alert, { foreignKey: "nurseId", as: "alerts" });
Alert.belongsTo(Nurse, { foreignKey: "nurseId", as: "nurse" });
// Patient → Alert
Patient.hasMany(Alert, { foreignKey: "patientId", as: "alerts" });
Alert.belongsTo(Patient, { foreignKey: "patientId", as: "patient" });
// ============================
// Exportar
// ============================
module.exports = {
 sequelize,
 Sequelize,
 Hospital,
 Nurse,
 User,
 Patient,
 Pathology,
 Device,
 Alert,
};