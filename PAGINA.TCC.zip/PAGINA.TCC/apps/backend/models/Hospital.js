const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");
class Hospital extends Model {}
Hospital.init({
 nombre: { type: DataTypes.STRING, allowNull: false },
 direccion: { type: DataTypes.STRING, allowNull: true },
}, {
 sequelize,
 modelName: "Hospital",
 tableName: "hospitals",
 timestamps: true,
});
module.exports = Hospital;