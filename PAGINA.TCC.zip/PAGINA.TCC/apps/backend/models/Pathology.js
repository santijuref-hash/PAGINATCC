const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");
class Pathology extends Model {}
Pathology.init({
 name: { type: DataTypes.STRING, allowNull: false },
 level: { type: DataTypes.STRING, allowNull: false },
 hospitalld: { type: DataTypes.INTEGER, allowNull: false },
}, {
 sequelize,
 modelName: "Pathology",
 tableName: "pathologies",
 timestamps: true,
});
module.exports = Pathology