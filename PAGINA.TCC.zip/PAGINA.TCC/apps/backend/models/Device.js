// models/Device.js (CORREGIDO)
const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");

class Device extends Model {}
Device.init(
  {
    nombre: { type: DataTypes.STRING, allowNull: false },
    tipo: { type: DataTypes.STRING, allowNull: true },
    simulacion: { type: DataTypes.BOOLEAN, defaultValue: false },
    hospitalld: { type: DataTypes.INTEGER, allowNull: false },
    activo: { type: DataTypes.BOOLEAN, defaultValue: false }, 
    patientId: {
      type: DataTypes.INTEGER,
      references: { model: 'patients', key: 'id' },
      allowNull: true
    },
    
    // --- ¡¡COLUMNA NUEVA!! ---
    // La usamos para guardar el ID físico (MAC Address) del TCC real
    macAddress: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true // No pueden existir dos TCC con la misma MAC
    }
  },
  {
    sequelize,
    modelName: "Device",
    tableName: "devices",
    timestamps: true,
  }
);
module.exports = Device;