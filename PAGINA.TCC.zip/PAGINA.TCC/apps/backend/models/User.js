const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");
class User extends Model {}
User.init({
 usuario: { type: DataTypes.STRING, allowNull: false, unique: true },
 password: { type: DataTypes.STRING, allowNull: false },
 role: { type: DataTypes.STRING, allowNull: false },
 hospitalld: {
    type: DataTypes.INTEGER,
    references: {
      model: 'hospitals', // Nombre de la tabla de hospitales
      key: 'id',
    },
    allowNull: true // O false, dependiendo de tu lógica
  }
}, {
 sequelize,
 modelName: "User",
 tableName: "users",
 timestamps: true,
});
module.exports = User;