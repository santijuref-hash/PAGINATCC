const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");

class Patient extends Model {}
Patient.init({
  nombre: { type: DataTypes.STRING, allowNull: false },
  dni: { type: DataTypes.STRING, allowNull: false, unique: true },
  edad: { type: DataTypes.INTEGER, allowNull: true },
  patologia: { type: DataTypes.STRING, allowNull: true },
  tcc: { type: DataTypes.STRING, allowNull: true },
  // Relaciones 🔹
  hospitalld: { type: DataTypes.INTEGER, allowNull: false }, // <-- CORREGIDO A "L"
  nurseId: { type: DataTypes.INTEGER, allowNull: true }, // nurseId (con I) está bien
}, {
  sequelize,
  modelName: "Patient",
  tableName: "patients",
  timestamps: true,
});
module.exports = Patient;