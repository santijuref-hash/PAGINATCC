const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");

class Alert extends Model {}

Alert.init({
  // --- Definiciones de Columnas ---
  deviceId: { 
    type: DataTypes.INTEGER, 
    allowNull: false 
  },
  urgency: { 
    type: DataTypes.STRING, 
    allowNull: false 
  },
  need: { 
    type: DataTypes.STRING, 
    allowNull: false 
  },
  timestamp: { 
    type: DataTypes.DATE, 
    defaultValue: DataTypes.NOW 
  },
  patientId: { 
    type: DataTypes.INTEGER, 
    allowNull: false 
  },
  nurseId: { 
    type: DataTypes.INTEGER, 
    allowNull: true // Correcto: permite nulos para el simulador
  },
  nota: { type: DataTypes.STRING, allowNull: true },
}, {
  // --- Opciones del Modelo ---
  sequelize, // La instancia de Sequelize (ahora en el lugar correcto)
  modelName: "Alert",
  tableName: "alerts",
  timestamps: true,
});

module.exports = Alert;