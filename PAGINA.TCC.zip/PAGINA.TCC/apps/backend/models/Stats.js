const { Model, DataTypes } = require("sequelize");
const sequelize = require("../db");
class Stat extends Model {}
Stat.init({
 hospitalId: { type: DataTypes.INTEGER, allowNull: false },
 totalTcc: { type: DataTypes.INTEGER, defaultValue: 0 },
 activos: { type: DataTypes.INTEGER, defaultValue: 0 },
 dadosAlta: { type: DataTypes.INTEGER, defaultValue: 0 },
 pacientesAtendidos: { type: DataTypes.INTEGER, defaultValue: 0 },
 tiempoRespuesta: { type: DataTypes.FLOAT, defaultValue: 0 },
}, {
 sequelize,
 modelName: "Stat",
 tableName: "stats",
 timestamps: true,
});
module.exports = Stat;