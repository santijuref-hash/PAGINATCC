const express = require('express');
const router = express.Router();
const { User, Hospital } = require('../models');
const bcrypt = require('bcryptjs');
// Obtener todos los usuarios con su hospital
router.get('/', async (req, res) => {
 try {
 const users = await User.findAll({
 include: [{ model: Hospital, as: 'hospital' }]
 });
 res.json(users);
 } catch (error) {
 console.error('Error al obtener usuarios:', error);
 res.status(500).json({ message: 'Error al obtener usuarios', error: error.message });
 }
});
// Crear usuario (admin/enfermera)
router.post('/', async (req, res) => {
 try {
 const { usuario, password, role, hospitalld } = req.body;
 // Verificar hospital
 let hospitalNombre = null;
 if (hospitalld) {
 const hospital = await Hospital.findByPk(hospitalld);
 if (!hospital) return res.status(404).json({ message: 'Hospital no encontrado' });
 hospitalNombre = hospital.nombre;
 }
 const hashedPassword = await bcrypt.hash(password, 10);
 const newUser = await User.create({ usuario, password: hashedPassword, role,
hospitalId });
 res.status(201).json({
 id: newUser.id,
 usuario: newUser.usuario,
 role: newUser.role,
 hospitalId: newUser.hospitalId,
 hospitalNombre
 });
 } catch (error) {
 console.error('No se pudo crear el usuario:', error);
 if (error.name === 'SequelizeUniqueConstraintError') {
 return res.status(400).json({ message: 'El usuario ya existe' });
 }
 res.status(500).json({ message: 'Error al crear usuario', error: error.message });
 }
});
// Obtener un usuario por ID
router.get('/:id', async (req, res) => {
 try {
 const user = await User.findByPk(req.params.id, {
 include: [{ model: Hospital, as: 'hospital' }]
 });
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 res.json(user);
 } catch (error) {
 console.error('Error al obtener usuario:', error);
 res.status(500).json({ message: 'Error al obtener usuario', error: error.message });
 }
});
// Actualizar usuario
router.put('/:id', async (req, res) => {
 try {
 const { usuario, password, role, hospitalld } = req.body;
 const user = await User.findByPk(req.params.id);
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 if (usuario) user.usuario = usuario;
 if (role) user.role = role;
 if (password) user.password = await bcrypt.hash(password, 10);
 if (hospitalId) user.hospitalld = hospitalld;
 await user.save();
 res.json(user);
 } catch (error) {
   console.error('Error al actualizar usuario:', error);
 res.status(500).json({ message: 'Error al actualizar usuario', error: error.message });
 }
});
// Eliminar usuario
router.delete('/:id', async (req, res) => {
 try {
 const user = await User.findByPk(req.params.id);
 if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
 await user.destroy();
 res.json({ message: 'Usuario eliminado correctamente' });
 } catch (error) {
 console.error('Error al eliminar usuario:', error);
 res.status(500).json({ message: 'Error al eliminar usuario', error: error.message });
 }
});
module.exports = router;