const express = require("express");
const router = express.Router();
const Device = require("../models/Device");
const { Hospital } = require("../models"); // Para verificar hospitales
// GET /devices/hospital/:id -> trae todos los dispositivos de un hospital ✅
router.get("/hospital/:id", async (req, res) => {
 try {
 const { id } = req.params;
 const devices = await Device.findAll({ where: { hospitalId: id } });
 res.json(devices);
 } catch (error) {
 console.error("Error al obtener dispositivos:", error);
 res.status(500).json({ error: "Error al obtener dispositivos" });
 }
});
// POST /devices/simulated -> crear un dispositivo simulado ✅
router.post("/simulated", async (req, res) => {
 try {
 const { hospitalld, nombre, tipo } = req.body;
 const device = await Device.create({
 hospitalld,
 nombre,
 tipo: tipo || "TCC simulado",
 simulacion: true,
 });
 res.json(device);
 } catch (error) {
 console.error("Error al crear dispositivo simulado:", error);
 res.status(500).json({ error: "Error al crear dispositivo simulado" });
 }
});
// PUT /devices/:id/encendido -> cambiar estado activo (ON/OFF) ✅
router.put("/:id/encendido", async (req, res) => {
 try {
 const { id } = req.params;
 const device = await Device.findByPk(id);
 if (!device) return res.status(404).json({ error: "Dispositivo no encontrado" });
 device.activo = !device.activo; // alterna entre true/false
 await device.save();
 res.json(device);
  } catch (error) {
 console.error("Error al encender/apagar dispositivo:", error);
 res.status(500).json({ error: "Error al cambiar estado del dispositivo" });
 }
});
// PUT /devices/:id/asignar-paciente -> asignar paciente a un TCC ✅
router.put("/:id/asignar-paciente", async (req, res) => {
 try {
 const { id } = req.params;
 const { patientId } = req.body;
 const device = await Device.findByPk(id);
 if (!device) return res.status(404).json({ error: "Dispositivo no encontrado" });
 device.patientId = patientId || null; // puede desasignarse con null
 await device.save();
 res.json(device);
 } catch (error) {
 console.error("Error al asignar paciente:", error);
 res.status(500).json({ error: "Error al asignar paciente al dispositivo" });
 }
});
// NUEVO: POST /devices/connect -> conectar TCC real (ESP32) y vincular a hospital ✅
router.post("/connect", async (req, res) => {
 try {
 const { deviceId, nombre, hospitalld } = req.body;
 if (!deviceId) return res.status(400).json({ error: "Falta deviceId" });
 // Verificar hospital
 let hospital = null;
 if (hospitalld) {
 hospital = await Hospital.findByPk(hospitalld);
 if (!hospital) return res.status(400).json({ error: "Hospital no encontrado" });
 }
 // Buscar si el dispositivo ya existe
 let device = await Device.findOne({ where: { id: deviceId } });
 if (device) {
 // Actualizar hospitalId y estado activo
 if (hospital) device.hospitalld = hospital.id;
 device.activo = true;
 await device.save();
 } else {
 // Crear nuevo dispositivo real
 device = await Device.create({
 id: deviceId,
 nombre: nombre || `TCC ${deviceId}`,
 tipo: "TCC real",
 hospitalld: hospital ? hospital.id : null,
 simulacion: false,
 activo: true,
 });
 }
 res.json({
 message: "Dispositivo conectado correctamente",
 device,
 });
 } catch (error) {
 console.error("Error al conectar dispositivo real:", error);
 res.status(500).json({ error: "Error al conectar dispositivo real" });
 }
});
module.exports = router;
