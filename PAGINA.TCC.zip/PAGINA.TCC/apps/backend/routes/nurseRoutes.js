const express = require("express");
const router = express.Router();
const { Nurse } = require("../models");
// LISTAR ENFERMERAS POR HOSPITAL
router.get("/hospital/:hospitalld", async (req, res) => {
 try {
 const enfermeras = await Nurse.findAll({ where: { hospitalId: req.params.hospitalId },
attributes: { exclude: ["password"] } });
 res.json(enfermeras);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener enfermeras" });
 }
});
// CREAR ENFERMERA
router.post("/", async (req, res) => {
 const { usuario, password, hospitalld } = req.body;
 if (!usuario || !password || !hospitalld) return res.status(400).json({ message: "Faltan datos" });
 try {
 const nuevaEnfermera = await Nurse.create({ usuario, password, hospitalld });
 res.status(201).json(nuevaEnfermera);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "No se pudo registrar la enfermera" });
 }
});
// ELIMINAR ENFERMERA
router.delete("/:id", async (req, res) => {
 try {
 const enfermera = await Nurse.findByPk(req.params.id);
 if (!enfermera) return res.status(404).json({ message: "Enfermera no encontrada" });
 await enfermera.destroy();
 res.json({ message: "Enfermera eliminada" });
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "No se pudo eliminar la enfermera" });
 }
});
module.exports = router;
