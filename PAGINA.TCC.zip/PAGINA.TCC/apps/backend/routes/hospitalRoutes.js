const express = require("express");
const router = express.Router();
const { Hospital } = require("../models");
// LISTAR HOSPITALES
router.get("/", async (req, res) => {
 try {
 const hospitales = await Hospital.findAll();
 res.json(hospitales);
 } catch (err) {
 console.error("Error al obtener hospitales:", err);
 res.status(500).json({ message: "Error al obtener hospitales" });
 }
});
// CREAR HOSPITAL
router.post("/", async (req, res) => {
 const { nombre, direccion } = req.body;
 if (!nombre) return res.status(400).json({ message: "Falta nombre del hospital" });
 try {
 // Verificar duplicado
 const existingHospital = await Hospital.findOne({ where: { nombre } });
 if (existingHospital) {
 return res.status(400).json({ message: `El hospital "${nombre}" ya existe` });
 }
 const hospital = await Hospital.create({ nombre, direccion });
 res.status(201).json(hospital);
 } catch (err) {
 console.error("No se pudo crear el hospital:", err);
 res.status(500).json({ message: "No se pudo crear el hospital", error: err.message });
 }
});
module.exports = router;