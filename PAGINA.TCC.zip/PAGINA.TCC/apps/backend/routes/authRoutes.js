const express = require("express");
const router = express.Router();
const deviceController = require("../controllers/deviceController");
// Crear dispositivo real
router.post("/register", deviceController.register);
// Heartbeat de dispositivo
router.post("/heartbeat", deviceController.heartbeat);
// Crear dispositivo simulado (desde CEO)
router.post("/simulated", deviceController.createSimulated);
// Listar dispositivos por hospital
router.get("/hospital/:id", async (req, res, next) => {
 try {
 const devices = await deviceController.listByHospital(req.params.id);
 res.json(devices);
 } catch (e) {
 next(e);
 }
});
module.exports = router;