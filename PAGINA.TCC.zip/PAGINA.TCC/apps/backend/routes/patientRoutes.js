// controllers/patientController.js
const { Patient } = require("../models");
const createPatient = async (req, res) => {
 try {
 const { nombre, dni, edad, patologia, tcc, hospitalld, nurseId } = req.body;
 // Validación mínima
 if (!nombre || !dni || !hospitalld) {
 return res.status(400).json({ message: "Faltan datos obligatorios" });
 }
 // Crear paciente
 const nuevoPaciente = await Patient.create({
 nombre,
 dni,
 edad: edad || null,
 patologia: patologia || null,
 tcc: tcc || null,
 hospitalld,
 nurseId: nurseId || null,
 });
 res.status(201).json(nuevoPaciente);
 } catch (err) {
 console.error("Error al crear paciente:", err);
 if (err.name === "SequelizeUniqueConstraintError") {
 return res.status(400).json({ message: "Ya existe un paciente con ese DNI" });
 }
 res.status(500).json({ message: "Error al crear paciente" });
 }
};
const getPatients = async (req, res) => {
 try {
 const { hospitalld } = req.query;
 const whereClause = hospitalld ? { hospitalld } : {};
 const pacientes = await Patient.findAll({ where: whereClause });
 res.json(pacientes);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener pacientes" });
 }
};
module.exports = { createPatient, getPatients };