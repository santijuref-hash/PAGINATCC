const express = require("express");
const router = express.Router();
const Alert = require("../models/Alert");
// POST /alerts
router.post("/", async (req, res) => {
 const { device_id, need, priority } = req.body;
 const alert = await Alert.create({ device_id, need, priority });
 res.json(alert);
});
module.exports = router;