// routes/statRoutes.js
const express = require("express");
const router = express.Router();
const { Stat, Hospital } = require("../models");
// Obtener estadísticas, opcionalmente filtrando por hospital
router.get("/", async (req, res) => {
 try {
 const { hospitalld } = req.query;
 const where = hospitalld ? { hospital_id: hospitalld } : {};
 const stats = await Stat.findAll({
 where,
 include: [{ model: Hospital, attributes: ["name"] }],
 });
 // Formatear para frontend
 const formatted = stats.map((s) => ({
 hospital: s.Hospital.name,
 total_tcc: s.total_tcc,
 activos: s.activos,
 dados_alta: s.dados_alta,
 pacientes_atendidos: s.pacientes_atendidos,
 tiempo_respuesta: s.tiempo_respuesta,
 }));
 res.json(formatted);
 } catch (err) {
 console.error(err);
 res.status(500).json({ message: "Error al obtener estadísticas" });
 }
});
module.exports = router;
