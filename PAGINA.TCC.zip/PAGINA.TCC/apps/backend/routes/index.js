const Sequelize = require("sequelize");
const sequelize = new Sequelize({
 dialect: "sqlite",
 storage: "database.sqlite",
});
const models = {
 Hospital: require("./Hospital")(sequelize, Sequelize.DataTypes),
 Nurse: require("./Nurse")(sequelize, Sequelize.DataTypes),
 User: require("./User")(sequelize, Sequelize.DataTypes),
 Patient: require("./Patient")(sequelize, Sequelize.DataTypes), // agregado ✅
};
// ============================
// Asociaciones
// ============================
// Un hospital tiene muchas enfermeras
models.Hospital.hasMany(models.Nurse, { foreignKey: "hospitalld", as: "nurses" });
models.Nurse.belongsTo(models.Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Un hospital tiene muchos pacientes
models.Hospital.hasMany(models.Patient, { foreignKey: "hospitalld", as: "patients" });
models.Patient.belongsTo(models.Hospital, { foreignKey: "hospitalld", as: "hospital" });
// Una enfermera tiene muchos pacientes
models.Nurse.hasMany(models.Patient, { foreignKey: "nurseId", as: "patients" });
models.Patient.belongsTo(models.Nurse, { foreignKey: "nurseId", as: "nurse" });
// Relación Usuario - Hospital
models.Hospital.hasMany(models.User, { foreignKey: "hospitalld", as: "users" });
models.User.belongsTo(models.Hospital, { foreignKey: "hospitalld", as: "hospital" });
models.sequelize = sequelize;
models.Sequelize = Sequelize;
module.exports = models;
